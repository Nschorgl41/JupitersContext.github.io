const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const { spawn } = require("node:child_process");
const {
  APP_VERSION,
  REGISTRY_VERSION,
  SETTINGS_SCHEMA_VERSION,
  BROWSER_SCHEMA_VERSION,
  health: systemHealth,
  migrateDashboardSettings,
  atomicWriteJson,
  buildRegistry,
  validateRegistry,
} = require("./system-foundation.cjs");

const APP_ROOT = __dirname;
const PORT = 4175;
const TIMEZONE = "America/Chicago";
const SPOTIFY_REDIRECT_URI = `http://127.0.0.1:${PORT}/spotify/callback`;
const REDDIT_REDIRECT_URI = `http://127.0.0.1:${PORT}/reddit/callback`;
const REDDIT_SCOPES = "identity read";
const REDDIT_AUTH_BASE = process.env.REDDIT_AUTH_BASE || "https://www.reddit.com";
const REDDIT_API_BASE = process.env.REDDIT_API_BASE || "https://oauth.reddit.com";
const GOOGLE_NEWS_BASE = process.env.GOOGLE_NEWS_BASE || "https://news.google.com/rss/search";
const BLUESKY_SERVICE_BASE = process.env.BLUESKY_SERVICE_BASE || "https://bsky.social";
const SPOTIFY_SCOPES = [
  "user-read-playback-state",
  "user-read-currently-playing",
  "user-modify-playback-state",
].join(" ");
const SPOTIFY_DATA_DIR = process.env.LOCALAPPDATA
  ? path.join(process.env.LOCALAPPDATA, "FrancisMorningDashboard")
  : APP_ROOT;
const SPOTIFY_CONFIG_PATH = process.env.SPOTIFY_CONFIG_PATH
  || path.join(SPOTIFY_DATA_DIR, "spotify-connection.json");
const GOOGLE_CALENDAR_CONFIG_PATH = process.env.GOOGLE_CALENDAR_CONFIG_PATH
  || path.join(SPOTIFY_DATA_DIR, "google-calendar-connection.json");
const DASHBOARD_SETTINGS_PATH = process.env.DASHBOARD_SETTINGS_PATH
  || path.join(SPOTIFY_DATA_DIR, "dashboard-settings.json");
const REDDIT_CACHE_PATH = process.env.REDDIT_CACHE_PATH
  || path.join(SPOTIFY_DATA_DIR, "reddit-feed-cache.json");
const REDDIT_CONFIG_PATH = process.env.REDDIT_CONFIG_PATH
  || path.join(SPOTIFY_DATA_DIR, "reddit-connection.json");
const DEFAULT_VAULT_ROOT = process.platform === "win32"
  ? "M:\\Francis OS"
  : path.join(APP_ROOT, "Francis OS");
const DEFAULT_NOTEBOOK_EXPORT_ROOT = path.join(DEFAULT_VAULT_ROOT, "Notebook Exports");
const DEFAULT_DASHBOARD_SETTINGS = Object.freeze({
  schemaVersion: SETTINGS_SCHEMA_VERSION,
  version: 1,
  systemMeta: {
    registryVersion: REGISTRY_VERSION,
    migratedFromSchema: 0,
    migratedByAppVersion: APP_VERSION,
  },
  name: "Francis",
  location: {
    label: "Austin, Texas",
    latitude: 30.2986,
    longitude: -97.7028,
    timezone: "America/Chicago",
  },
  storagePath: DEFAULT_VAULT_ROOT,
  notesExportPath: DEFAULT_NOTEBOOK_EXPORT_ROOT,
  newsTopics: [
    { label: "TOP STORY", query: "top US news when:1d" },
    { label: "AI & TECHNOLOGY", query: "AI technology Microsoft OpenAI when:1d" },
    { label: "CYBERSECURITY", query: "cybersecurity vulnerability CISA when:1d" },
    { label: "BUSINESS", query: "US business markets economy when:1d" },
    { label: "AUSTIN", query: "Austin Texas local news when:1d" },
  ],
  defaults: {
    themeMode: "auto",
    vaultView: "recent",
    youtubeId: "jfKfPfyJRdk",
  },
});
const VAULT_CATEGORIES = Object.freeze({
  photos: "Family Photos",
  videos: "Family Videos",
  projects: "Personal Projects",
  private: "Private Vault",
});
const VAULT_MAX_UPLOAD_BYTES = 10 * 1024 * 1024 * 1024;
const privateSessions = new Map();
function validPrivateSession(token) {
  const expiresAt = privateSessions.get(String(token || ""));
  if (!expiresAt || expiresAt < Date.now()) {
    if (token) privateSessions.delete(String(token));
    return false;
  }
  privateSessions.set(String(token), Date.now() + 10 * 60_000);
  return true;
}

const BLUESKY_ADULT_LABELS = new Set([
  "porn",
  "sexual",
  "nudity",
  "graphic-media",
]);

function cleanBlueskyHandle(value) {
  const raw = String(value || "").trim();
  const profile = raw.match(/^https?:\/\/bsky\.app\/profile\/([^/?#]+)/i);
  return decodeURIComponent(profile ? profile[1] : raw.replace(/^@/, "")).slice(0, 253);
}

function blueskySessionValue(value = {}) {
  const accessJwt = String(value.accessJwt || "");
  const refreshJwt = String(value.refreshJwt || "");
  const did = String(value.did || "");
  const handle = cleanBlueskyHandle(value.handle);
  if (!accessJwt || !refreshJwt || !did || !handle) {
    throw vaultError("Reconnect Bluesky in Settings.", 401);
  }
  return { accessJwt, refreshJwt, did, handle };
}

async function blueskyXrpc(endpoint, {
  method = "GET",
  token = "",
  params = {},
  body,
} = {}) {
  const requestUrl = new URL(`/xrpc/${endpoint}`, BLUESKY_SERVICE_BASE);
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== "") requestUrl.searchParams.set(key, String(value));
  });
  const response = await fetch(requestUrl, {
    method,
    headers: {
      Accept: "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(body ? { "Content-Type": "application/json" } : {}),
      "User-Agent": "Francis-Dashboard-Windows/45.0",
    },
    ...(body ? { body: JSON.stringify(body) } : {}),
  });
  const value = await response.json().catch(() => ({}));
  if (!response.ok) {
    const message = value.message || value.error || `Bluesky returned ${response.status}`;
    throw vaultError(message, response.status);
  }
  return value;
}

async function connectBluesky(identifier, appPassword) {
  const handle = cleanBlueskyHandle(identifier);
  const password = String(appPassword || "").trim();
  if (!handle || !password) throw vaultError("Enter your Bluesky handle and an App Password.");
  const session = await blueskyXrpc("com.atproto.server.createSession", {
    method: "POST",
    body: { identifier: handle, password },
  });
  return blueskySessionValue(session);
}

async function refreshBlueskySession(session) {
  const current = blueskySessionValue(session);
  const refreshed = await blueskyXrpc("com.atproto.server.refreshSession", {
    method: "POST",
    token: current.refreshJwt,
  });
  return blueskySessionValue(refreshed);
}

async function blueskyAuthed(endpoint, session, params = {}) {
  let active = blueskySessionValue(session);
  try {
    return {
      value: await blueskyXrpc(endpoint, { token: active.accessJwt, params }),
      session: active,
    };
  } catch (error) {
    if (error.status !== 400 && error.status !== 401) throw error;
    active = await refreshBlueskySession(active);
    return {
      value: await blueskyXrpc(endpoint, { token: active.accessJwt, params }),
      session: active,
    };
  }
}

function blueskyPostUrl(post = {}) {
  const rkey = String(post.uri || "").split("/").pop();
  const actor = post.author?.handle || post.author?.did;
  return rkey && actor
    ? `https://bsky.app/profile/${encodeURIComponent(actor)}/post/${encodeURIComponent(rkey)}`
    : "https://bsky.app/";
}

function blueskyMedia(embed = {}) {
  const source = embed.media || embed;
  if (Array.isArray(source.images) && source.images.length) {
    return {
      type: "image",
      images: source.images.slice(0, 4).map((image) => ({
        thumb: String(image.thumb || image.fullsize || ""),
        fullsize: String(image.fullsize || image.thumb || ""),
        alt: String(image.alt || "").slice(0, 500),
      })).filter((image) => image.thumb),
    };
  }
  if (source.playlist || source.thumbnail || source.$type === "app.bsky.embed.video#view") {
    return {
      type: "video",
      thumbnail: String(source.thumbnail || ""),
      playlist: String(source.playlist || ""),
      alt: String(source.alt || "").slice(0, 500),
    };
  }
  if (source.external) {
    return {
      type: "external",
      thumbnail: String(source.external.thumb || ""),
      externalUrl: String(source.external.uri || ""),
      title: String(source.external.title || "").slice(0, 180),
    };
  }
  return { type: "text" };
}

function normalizeBlueskyPost(item = {}, source = {}) {
  const post = item.post || item;
  const labels = [
    ...(Array.isArray(post.labels) ? post.labels : []),
    ...(Array.isArray(post.author?.labels) ? post.author.labels : []),
  ].map((label) => String(label.val || "").toLowerCase()).filter(Boolean);
  const adult = labels.some((label) => BLUESKY_ADULT_LABELS.has(label));
  const media = blueskyMedia(post.embed || {});
  return {
    id: String(post.uri || post.cid || crypto.randomUUID()),
    uri: String(post.uri || ""),
    cid: String(post.cid || ""),
    url: blueskyPostUrl(post),
    text: String(post.record?.text || "").slice(0, 1200),
    createdAt: String(post.record?.createdAt || post.indexedAt || new Date().toISOString()),
    author: {
      did: String(post.author?.did || ""),
      handle: String(post.author?.handle || ""),
      displayName: String(post.author?.displayName || post.author?.handle || "Bluesky"),
      avatar: String(post.author?.avatar || ""),
    },
    media,
    labels,
    adult,
    source: {
      id: String(source.id || ""),
      label: String(source.label || source.value || "Bluesky"),
      type: String(source.type || "search"),
    },
    counts: {
      replies: Number(post.replyCount || 0),
      reposts: Number(post.repostCount || 0),
      likes: Number(post.likeCount || 0),
    },
  };
}

async function resolveBlueskyFeedUri(value, session) {
  const raw = String(value || "").trim();
  if (raw.startsWith("at://")) return { uri: raw, session };
  const match = raw.match(/^https?:\/\/bsky\.app\/profile\/([^/]+)\/feed\/([^/?#]+)/i);
  if (!match) throw vaultError("Paste a complete Bluesky feed URL or at:// feed URI.");
  const actor = decodeURIComponent(match[1]);
  let did = actor;
  let active = session;
  if (!actor.startsWith("did:")) {
    const resolved = await blueskyAuthed("com.atproto.identity.resolveHandle", active, { handle: actor });
    did = resolved.value.did;
    active = resolved.session;
  }
  return { uri: `at://${did}/app.bsky.feed.generator/${decodeURIComponent(match[2])}`, session: active };
}

async function readBlueskySource(source, session) {
  const type = ["profile", "search", "feed"].includes(source.type) ? source.type : "search";
  const value = String(source.value || "").trim();
  if (!value) return { posts: [], session };
  let result;
  if (type === "profile") {
    result = await blueskyAuthed("app.bsky.feed.getAuthorFeed", session, {
      actor: cleanBlueskyHandle(value),
      filter: "posts_with_media",
      limit: 25,
    });
  } else if (type === "feed") {
    const resolved = await resolveBlueskyFeedUri(value, session);
    result = await blueskyAuthed("app.bsky.feed.getFeed", resolved.session, {
      feed: resolved.uri,
      limit: 25,
    });
  } else {
    result = await blueskyAuthed("app.bsky.feed.searchPosts", session, {
      q: value.slice(0, 240),
      sort: "latest",
      limit: 25,
    });
  }
  const values = result.value.feed || result.value.posts || [];
  return {
    posts: values.map((post) => normalizeBlueskyPost(post, source)),
    session: result.session,
  };
}

async function readBlueskyFeed(value = {}) {
  let session = blueskySessionValue(value.session);
  const includeAdult = value.includeAdult === true;
  const sources = (Array.isArray(value.sources) ? value.sources : [])
    .filter((source) => source && source.enabled !== false)
    .slice(0, 10)
    .map((source) => ({
      id: String(source.id || "").slice(0, 100),
      type: String(source.type || "search"),
      label: cleanSettingText(source.label, String(source.value || "Bluesky"), 80),
      value: String(source.value || "").slice(0, 500),
    }));
  if (!sources.length) return { session, posts: [], fetchedAt: new Date().toISOString() };
  const collected = [];
  const errors = [];
  for (const source of sources) {
    try {
      const result = await readBlueskySource(source, session);
      session = result.session;
      collected.push(...result.posts);
    } catch (error) {
      errors.push({ sourceId: source.id, message: error.message });
    }
  }
  const seen = new Set();
  const posts = collected
    .filter((post) => (includeAdult || !post.adult) && !seen.has(post.id) && seen.add(post.id))
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
    .slice(0, 80);
  return { session, posts, errors, fetchedAt: new Date().toISOString() };
}

function cleanSettingText(value, fallback, maxLength) {
  const cleaned = String(value ?? "").replace(/[\u0000-\u001F\u007F]/g, "").trim();
  return (cleaned || fallback).slice(0, maxLength);
}

function validTimezone(value) {
  if (typeof value !== "string" || !value.trim()) return false;
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: value.trim() }).format(new Date());
    return true;
  } catch {
    return false;
  }
}

function normalizeDashboardSettings(value = {}) {
  const location = value.location && typeof value.location === "object" ? value.location : {};
  const defaults = value.defaults && typeof value.defaults === "object" ? value.defaults : {};
  const latitude = Number(location.latitude);
  const longitude = Number(location.longitude);
  const suppliedTopics = Array.isArray(value.newsTopics) ? value.newsTopics : [];
  const newsTopics = DEFAULT_DASHBOARD_SETTINGS.newsTopics.map((fallback, index) => {
    const topic = suppliedTopics[index] && typeof suppliedTopics[index] === "object"
      ? suppliedTopics[index]
      : {};
    return {
      label: cleanSettingText(topic.label, fallback.label, 36).toUpperCase(),
      query: cleanSettingText(topic.query, fallback.query, 180),
    };
  });
  const storagePath = cleanSettingText(value.storagePath, DEFAULT_VAULT_ROOT, 500);
  const notesExportPath = cleanSettingText(
    value.notesExportPath,
    path.join(storagePath, "Notebook Exports"),
    500,
  );
  return {
    schemaVersion: SETTINGS_SCHEMA_VERSION,
    version: 1,
    systemMeta: {
      registryVersion: REGISTRY_VERSION,
      migratedFromSchema: Number.isInteger(Number(value.systemMeta?.migratedFromSchema))
        ? Number(value.systemMeta.migratedFromSchema)
        : 0,
      migratedByAppVersion: Number.isInteger(Number(value.systemMeta?.migratedByAppVersion))
        ? Number(value.systemMeta.migratedByAppVersion)
        : APP_VERSION,
    },
    name: cleanSettingText(value.name, DEFAULT_DASHBOARD_SETTINGS.name, 40),
    location: {
      label: cleanSettingText(location.label, DEFAULT_DASHBOARD_SETTINGS.location.label, 90),
      latitude: Number.isFinite(latitude) && latitude >= -90 && latitude <= 90
        ? latitude
        : DEFAULT_DASHBOARD_SETTINGS.location.latitude,
      longitude: Number.isFinite(longitude) && longitude >= -180 && longitude <= 180
        ? longitude
        : DEFAULT_DASHBOARD_SETTINGS.location.longitude,
      timezone: validTimezone(location.timezone)
        ? String(location.timezone).trim()
        : DEFAULT_DASHBOARD_SETTINGS.location.timezone,
    },
    storagePath,
    notesExportPath,
    newsTopics,
    defaults: {
      themeMode: ["auto", "day", "night"].includes(defaults.themeMode)
        ? defaults.themeMode
        : DEFAULT_DASHBOARD_SETTINGS.defaults.themeMode,
      vaultView: ["recent", "photos", "videos", "projects"].includes(defaults.vaultView)
        ? defaults.vaultView
        : DEFAULT_DASHBOARD_SETTINGS.defaults.vaultView,
      youtubeId: /^[\w-]{11}$/.test(String(defaults.youtubeId || ""))
        ? String(defaults.youtubeId)
        : DEFAULT_DASHBOARD_SETTINGS.defaults.youtubeId,
    },
  };
}

let dashboardSettingsCache;
let dashboardSettingsMigration = {
  changed: false,
  fromVersion: SETTINGS_SCHEMA_VERSION,
  toVersion: SETTINGS_SCHEMA_VERSION,
  applied: [],
};
function readDashboardSettings() {
  if (dashboardSettingsCache) return dashboardSettingsCache;
  try {
    const rawSettings = JSON.parse(fs.readFileSync(DASHBOARD_SETTINGS_PATH, "utf8"));
    dashboardSettingsMigration = migrateDashboardSettings(rawSettings);
    dashboardSettingsCache = normalizeDashboardSettings(dashboardSettingsMigration.value);
    if (dashboardSettingsMigration.changed) {
      atomicWriteJson(DASHBOARD_SETTINGS_PATH, dashboardSettingsCache);
    }
  } catch {
    dashboardSettingsCache = normalizeDashboardSettings();
  }
  return dashboardSettingsCache;
}

function writeDashboardSettings(value) {
  const migration = migrateDashboardSettings(value);
  const settings = normalizeDashboardSettings(migration.value);
  atomicWriteJson(DASHBOARD_SETTINGS_PATH, settings);
  dashboardSettingsCache = settings;
  dashboardSettingsMigration = migration;
  if (typeof runtimeSystemHealth === "object") {
    delete runtimeSystemHealth.applications.files;
    delete runtimeSystemHealth.applications.notebook;
    delete runtimeSystemHealth.integrations["local-filesystem"];
  }
  return settings;
}

function currentVaultRoot() {
  return process.env.FRANCIS_VAULT_ROOT || readDashboardSettings().storagePath;
}

const runtimeSystemHealth = {
  applications: {},
  integrations: {},
};

function markApplicationHealth(applicationId, status, detail) {
  runtimeSystemHealth.applications[applicationId] = systemHealth(status, detail);
}

function markIntegrationHealth(integrationId, status, detail) {
  runtimeSystemHealth.integrations[integrationId] = systemHealth(status, detail);
}

function pathHealth(target, readyDetail) {
  try {
    if (target && fs.existsSync(target)) return systemHealth("ready", readyDetail);
    return systemHealth("not_configured", `${target || "The configured path"} is not currently available.`);
  } catch (error) {
    return systemHealth("unavailable", error.message);
  }
}

function buildCurrentSystemRegistry(activeWorkspace = "work") {
  const settings = readDashboardSettings();
  const spotify = readSpotifyConfig();
  const calendar = readGoogleCalendarConfig();
  const vault = pathHealth(currentVaultRoot(), "Personal Vault path is available.");
  const exports = pathHealth(settings.notesExportPath, "Notebook export path is available.");
  const integrationHealth = {
    "local-settings": systemHealth("ready", "Versioned dashboard settings are available."),
    "browser-storage": systemHealth("ready", "Browser-managed user data is registered."),
    "local-filesystem": vault.status === "unavailable"
      ? vault
      : systemHealth("ready", "Windows storage locations are registered."),
    "open-meteo": systemHealth("ready", "Public weather integration is registered."),
    "google-news": systemHealth("ready", "Public news integration is registered."),
    "google-calendar": calendar.secretIcalUrl
      ? systemHealth("ready", "A private Google Calendar feed is configured.")
      : systemHealth("not_configured", "Google Calendar has not been connected."),
    spotify: spotify.clientId && spotify.refreshToken
      ? systemHealth("ready", "Spotify playback is connected.")
      : systemHealth("not_configured", "Spotify has not been connected."),
    youtube: systemHealth("ready", "Privacy-enhanced YouTube embeds are available."),
    chatgpt: systemHealth("ready", "ChatGPT requests open in a separate browser tab."),
    ...runtimeSystemHealth.integrations,
  };
  const applicationHealth = {
    settings: systemHealth("ready", `Settings schema ${SETTINGS_SCHEMA_VERSION} is active.`),
    files: vault,
    notebook: exports.status === "unavailable"
      ? systemHealth("degraded", "Notebook is available, but the export path needs attention.")
      : systemHealth("ready", "Notebook state and Word exports are registered."),
    ...runtimeSystemHealth.applications,
  };
  const storageLocations = [
    {
      storageLocationId: "browser-local-storage",
      name: "Browser User Data",
      type: "browser",
      path: "localStorage",
      permissions: ["read", "write"],
      health: systemHealth("ready", `Browser schema ${BROWSER_SCHEMA_VERSION} is registered.`),
    },
    {
      storageLocationId: "local-app-data",
      name: "Local Application Data",
      type: "filesystem",
      path: SPOTIFY_DATA_DIR,
      permissions: ["read", "write"],
      health: pathHealth(SPOTIFY_DATA_DIR, "Local application-data path is available."),
    },
    {
      storageLocationId: "personal-vault",
      name: "Personal Vault",
      type: "filesystem",
      path: currentVaultRoot(),
      permissions: ["read", "write", "open"],
      health: vault,
    },
    {
      storageLocationId: "notebook-exports",
      name: "Notebook Exports",
      type: "filesystem",
      path: settings.notesExportPath,
      permissions: ["write"],
      health: exports,
    },
  ];
  const registry = buildRegistry({
    activeWorkspace: ["work", "personal", "focus"].includes(activeWorkspace) ? activeWorkspace : "work",
    applicationHealth,
    integrationHealth,
    storageLocations,
  });
  validateRegistry(registry);
  return {
    ...registry,
    migrations: {
      settings: {
        schemaVersion: SETTINGS_SCHEMA_VERSION,
        lastRead: dashboardSettingsMigration,
      },
      browser: {
        schemaVersion: BROWSER_SCHEMA_VERSION,
        owner: "system-foundation-browser.js",
      },
    },
  };
}

function json(response, status, value) {
  response.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
  });
  response.end(JSON.stringify(value));
}

let activeFolderPicker = null;
function pickWindowsFolder(initialPath, description) {
  if (process.platform !== "win32") {
    throw vaultError("The native folder picker is available in the Windows dashboard.", 503);
  }
  if (activeFolderPicker) {
    throw vaultError("A folder picker is already open. Choose a folder or close that window first.", 409);
  }
  return new Promise((resolve, reject) => {
    const child = spawn("powershell.exe", [
      "-NoProfile",
      "-STA",
      "-ExecutionPolicy",
      "Bypass",
      "-File",
      path.join(APP_ROOT, "folder-picker.ps1"),
    ], {
      windowsHide: false,
      env: {
        ...process.env,
        DASHBOARD_PICKER_INITIAL: String(initialPath || "").slice(0, 500),
        DASHBOARD_PICKER_DESCRIPTION: String(description || "Choose a folder").slice(0, 140),
      },
      stdio: ["ignore", "pipe", "pipe"],
    });
    activeFolderPicker = child;
    let stdout = "";
    let stderr = "";
    let settled = false;
    let timeout;
    const finish = (callback) => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      if (activeFolderPicker === child) activeFolderPicker = null;
      callback();
    };
    timeout = setTimeout(() => {
      child.kill();
      finish(() => reject(vaultError("The folder picker did not respond. Try Browse again.", 503)));
    }, 120_000);
    child.stdout.setEncoding("utf8");
    child.stderr.setEncoding("utf8");
    child.stdout.on("data", (chunk) => { stdout += chunk; });
    child.stderr.on("data", (chunk) => { stderr += chunk; });
    child.on("error", (error) => finish(() => reject(vaultError(`Windows could not open the folder picker: ${error.message}`, 500))));
    child.on("close", (code) => {
      finish(() => {
        if (code !== 0) {
          reject(vaultError(stderr.trim() || "Windows closed the folder picker unexpectedly.", 500));
          return;
        }
        resolve(stdout.trim());
      });
    });
  });
}

function notebookExportFilename(ownerName, now = new Date()) {
  const owner = String(ownerName || "dashboard")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "") || "dashboard";
  const stamp = now.toISOString().replace(/[:T]/g, "-").slice(0, 19);
  return `${owner}-notebook-${stamp}.docx`;
}

const REDDIT_SORTS = new Set(["hot", "new", "top"]);
const REDDIT_TOP_TIMES = new Set(["hour", "day", "week", "month", "year", "all"]);
const REDDIT_CACHE_TTL = 15 * 60_000;
const REDDIT_CACHE_MAX_AGE = 7 * 24 * 60 * 60_000;
const REDDIT_DEFAULT_BACKOFF = 15 * 60_000;
const redditCache = new Map();
let redditBackoffUntil = 0;

function readRedditConfig() {
  try {
    return JSON.parse(fs.readFileSync(REDDIT_CONFIG_PATH, "utf8"));
  } catch {
    return {};
  }
}

function writeRedditConfig(config) {
  fs.mkdirSync(path.dirname(REDDIT_CONFIG_PATH), { recursive: true });
  const temporaryPath = `${REDDIT_CONFIG_PATH}.tmp`;
  fs.writeFileSync(temporaryPath, JSON.stringify(config, null, 2), "utf8");
  fs.renameSync(temporaryPath, REDDIT_CONFIG_PATH);
}

function redditStatus() {
  const config = readRedditConfig();
  return {
    connected: Boolean(config.clientId && config.refreshToken),
    configured: Boolean(config.clientId),
    clientId: config.clientId || "",
    username: config.username || "",
    redirectUri: REDDIT_REDIRECT_URI,
    scopes: REDDIT_SCOPES.split(" "),
  };
}

function redditAccountKey() {
  const config = readRedditConfig();
  return config.refreshToken
    ? crypto.createHash("sha256").update(config.refreshToken).digest("hex").slice(0, 16)
    : "";
}

function clearRedditCache() {
  redditCache.clear();
  redditBackoffUntil = 0;
  try {
    if (fs.existsSync(REDDIT_CACHE_PATH)) fs.unlinkSync(REDDIT_CACHE_PATH);
  } catch {
    // A stale cache cannot be used after the account key changes.
  }
}

function redditBasicAuthorization(clientId) {
  return `Basic ${Buffer.from(`${clientId}:`).toString("base64")}`;
}

async function redditTokenRequest(clientId, form) {
  const response = await fetch(`${REDDIT_AUTH_BASE}/api/v1/access_token`, {
    method: "POST",
    headers: {
      Authorization: redditBasicAuthorization(clientId),
      "Content-Type": "application/x-www-form-urlencoded",
      "User-Agent": "FrancisDashboard/36.0 (local personal dashboard; read-only)",
    },
    body: new URLSearchParams(form),
  });
  const value = await response.json().catch(() => ({}));
  if (!response.ok || !value.access_token) {
    const error = value.error_description || value.error || `Reddit authorization returned ${response.status}`;
    throw vaultError(`Reddit connection failed: ${error}.`, 502);
  }
  return value;
}

async function redditAccessToken() {
  const config = readRedditConfig();
  if (!config.clientId || !config.refreshToken) {
    throw vaultError("Connect Reddit in Settings to load your Interests feed.", 401);
  }
  if (config.accessToken && Number(config.expiresAt || 0) > Date.now() + 60_000) {
    return config.accessToken;
  }
  try {
    const token = await redditTokenRequest(config.clientId, {
      grant_type: "refresh_token",
      refresh_token: config.refreshToken,
    });
    writeRedditConfig({
      ...config,
      accessToken: token.access_token,
      refreshToken: token.refresh_token || config.refreshToken,
      expiresAt: Date.now() + Number(token.expires_in || 3600) * 1000,
      scope: token.scope || config.scope || REDDIT_SCOPES,
    });
    return token.access_token;
  } catch (error) {
    if (error.status === 401 || /invalid_grant|unauthorized/i.test(error.message)) {
      writeRedditConfig({ clientId: config.clientId });
      throw vaultError("Your Reddit connection expired. Reconnect it in Settings.", 401);
    }
    throw error;
  }
}

async function redditApi(pathname, searchParams = {}) {
  const token = await redditAccessToken();
  const url = new URL(pathname, REDDIT_API_BASE);
  url.search = new URLSearchParams(searchParams).toString();
  const response = await fetch(url, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: "application/json",
      "User-Agent": "FrancisDashboard/36.0 (local personal dashboard; read-only)",
    },
  });
  if (response.status === 401) {
    const config = readRedditConfig();
    writeRedditConfig({ ...config, accessToken: "", expiresAt: 0 });
  }
  if (!response.ok) {
    const retrySeconds = Math.max(0, Number(response.headers.get("retry-after")) || 0);
    if (response.status === 429) {
      redditBackoffUntil = Date.now() + Math.max(60_000, retrySeconds * 1000);
      persistRedditCache();
    }
    const message = response.status === 401
      ? "Your Reddit connection needs to be renewed in Settings."
      : response.status === 403
        ? "Reddit did not allow access to one of these communities. It may be private, quarantined, or age-restricted."
        : response.status === 429
          ? "Reddit is briefly limiting requests. The saved feed will remain available."
          : `Reddit returned ${response.status}.`;
    throw vaultError(message, response.status === 401 ? 401 : 503);
  }
  return response.json();
}

function persistRedditCache() {
  try {
    fs.mkdirSync(path.dirname(REDDIT_CACHE_PATH), { recursive: true });
    const entries = [...redditCache.entries()]
      .sort((left, right) => right[1].savedAt - left[1].savedAt)
      .slice(0, 40)
      .map(([key, entry]) => ({ key, savedAt: entry.savedAt, value: entry.value }));
    const temporaryPath = `${REDDIT_CACHE_PATH}.tmp`;
    fs.writeFileSync(temporaryPath, JSON.stringify({ version: 1, redditBackoffUntil, entries }), "utf8");
    fs.renameSync(temporaryPath, REDDIT_CACHE_PATH);
  } catch {
    // The in-memory cache remains available if Windows blocks this local file.
  }
}

function hydrateRedditCache() {
  try {
    const stored = JSON.parse(fs.readFileSync(REDDIT_CACHE_PATH, "utf8"));
    redditBackoffUntil = Math.max(0, Number(stored.redditBackoffUntil) || 0);
    for (const entry of Array.isArray(stored.entries) ? stored.entries : []) {
      if (
        typeof entry.key === "string"
        && entry.value?.posts
        && Number(entry.savedAt) > Date.now() - REDDIT_CACHE_MAX_AGE
      ) {
        redditCache.set(entry.key, { savedAt: Number(entry.savedAt), value: entry.value });
      }
    }
  } catch {
    redditBackoffUntil = 0;
  }
}

function redditFallback(subreddits, includeNsfw, accountKey, exact) {
  if (exact?.value?.posts) return exact;
  const requested = new Set(subreddits.map((name) => name.toLowerCase()));
  return [...redditCache.values()]
    .filter((entry) => (
      entry.value?.posts
      && entry.value.accountKey === accountKey
      && entry.value.includeNsfw === includeNsfw
      && entry.value.subreddits?.some((name) => requested.has(String(name).toLowerCase()))
    ))
    .sort((left, right) => right.savedAt - left.savedAt)[0] || null;
}

hydrateRedditCache();

function normalizeSubreddits(value) {
  const values = Array.isArray(value) ? value : String(value || "").split(",");
  const seen = new Set();
  const result = [];
  for (const entry of values) {
    const name = String(entry || "")
      .trim()
      .replace(/^https?:\/\/(?:www\.)?reddit\.com\/r\//i, "")
      .replace(/^\/?r\//i, "")
      .split(/[/?#\s]/)[0];
    if (!/^[A-Za-z0-9_]{2,21}$/.test(name)) continue;
    const key = name.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    result.push(name);
    if (result.length === 12) break;
  }
  return result;
}

function trustedRedditImage(value) {
  if (typeof value !== "string" || !value) return "";
  try {
    const url = new URL(value.replace(/&amp;/g, "&"));
    const allowedHosts = new Set([
      "i.redd.it",
      "preview.redd.it",
      "external-preview.redd.it",
      "styles.redditmedia.com",
    ]);
    return url.protocol === "https:" && allowedHosts.has(url.hostname.toLowerCase())
      ? url.toString()
      : "";
  } catch {
    return "";
  }
}

function redditAtomValue(entry, tag) {
  return xmlText(entry.match(new RegExp(`<${tag}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${tag}>`, "i"))?.[1] || "");
}

function redditAtomLink(entry) {
  const href = entry.match(/<link\b[^>]*\bhref=(?:"([^"]+)"|'([^']+)')[^>]*>/i);
  const value = xmlText(href?.[1] || href?.[2] || "");
  try {
    const parsed = new URL(value);
    return ["http:", "https:"].includes(parsed.protocol) && /(^|\.)reddit\.com$/i.test(parsed.hostname)
      ? parsed.toString()
      : "https://www.reddit.com/";
  } catch {
    return "https://www.reddit.com/";
  }
}

function redditAtomThumbnail(entry) {
  const media = entry.match(/<media:thumbnail\b[^>]*\burl=(?:"([^"]+)"|'([^']+)')[^>]*>/i);
  if (media) return trustedRedditImage(xmlText(media[1] || media[2] || ""));
  const decoded = entry
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">");
  const image = decoded.match(/<img\b[^>]*\bsrc=(?:"([^"]+)"|'([^']+)')[^>]*>/i);
  return trustedRedditImage(image?.[1] || image?.[2] || "");
}

function normalizeRedditAtomPost(entry, matureSubreddits = new Set()) {
  const permalink = redditAtomLink(entry);
  const subreddit = permalink.match(/\/r\/([^/]+)/i)?.[1] || "Reddit";
  const published = redditAtomValue(entry, "published") || redditAtomValue(entry, "updated");
  const authorBlock = entry.match(/<author(?:\s[^>]*)?>([\s\S]*?)<\/author>/i)?.[1] || "";
  const author = redditAtomValue(authorBlock, "name").replace(/^\/?u\//i, "") || "unknown";
  const categoryTerms = [...entry.matchAll(/<category\b[^>]*\bterm=(?:"([^"]+)"|'([^']+)')[^>]*>/gi)]
    .map((match) => String(match[1] || match[2] || "").toLowerCase());
  const flaggedMature = categoryTerms.some((term) => ["nsfw", "over18", "over_18"].includes(term))
    || /\b(?:nsfw|over[_ -]?18)\b/i.test(entry);
  let domain = "reddit.com";
  try {
    domain = new URL(permalink).hostname.replace(/^www\./, "");
  } catch {}
  return {
    id: cleanSettingText(redditAtomValue(entry, "id") || permalink, "", 160),
    subreddit: cleanSettingText(subreddit, "Reddit", 80),
    title: cleanSettingText(redditAtomValue(entry, "title"), "Untitled post", 320),
    author: cleanSettingText(author, "unknown", 80),
    permalink,
    createdUtc: Math.max(0, Date.parse(published) / 1000 || 0),
    score: null,
    comments: null,
    over18: flaggedMature || matureSubreddits.has(subreddit.toLowerCase()),
    spoiler: /\bspoiler\b/i.test(entry),
    domain: cleanSettingText(domain, "reddit.com", 120),
    thumbnail: redditAtomThumbnail(entry),
  };
}

async function readRedditFeed(options = {}) {
  const subreddits = normalizeSubreddits(options.subreddits);
  if (!subreddits.length) throw vaultError("Add at least one valid subreddit.", 400);
  const sort = REDDIT_SORTS.has(options.sort) ? options.sort : "hot";
  const time = REDDIT_TOP_TIMES.has(options.time) ? options.time : "day";
  const includeNsfw = options.includeNsfw === true;
  const matureSubreddits = new Set(normalizeSubreddits(options.matureSubreddits).map((name) => name.toLowerCase()));
  const limit = Math.max(1, Math.min(50, Number(options.limit) || 40));
  const accountKey = redditAccountKey();
  if (!accountKey) throw vaultError("Connect Reddit in Settings to load your Interests feed.", 401);
  const cacheKey = JSON.stringify({
    accountKey,
    subreddits: subreddits.map((name) => name.toLowerCase()),
    sort,
    time,
    includeNsfw,
    matureSubreddits: [...matureSubreddits].sort(),
    limit,
  });
  const cached = redditCache.get(cacheKey);
  const fallback = redditFallback(subreddits, includeNsfw, accountKey, cached);
  if (cached && Date.now() - cached.savedAt < REDDIT_CACHE_TTL) {
    return { ...cached.value, cached: true };
  }
  if (Date.now() < redditBackoffUntil) {
    if (fallback) return { ...fallback.value, cached: true, stale: true, partial: fallback !== cached };
    const waitMinutes = Math.max(1, Math.ceil((redditBackoffUntil - Date.now()) / 60_000));
    throw vaultError(`Reddit asked the dashboard to pause. It will retry in about ${waitMinutes} minutes.`, 429);
  }

  try {
    const listing = await redditApi(`/r/${subreddits.map(encodeURIComponent).join("+")}/${sort}.json`, {
      raw_json: "1",
      limit: String(limit),
      ...(sort === "top" ? { t: time } : {}),
    });
    const posts = (listing?.data?.children || []).map((child) => {
      const post = child?.data || {};
      const subreddit = cleanSettingText(post.subreddit, "Reddit", 80);
      const permalink = /^\/r\//i.test(String(post.permalink || ""))
        ? `https://www.reddit.com${post.permalink}`
        : "https://www.reddit.com/";
      const imageCandidates = [
        post.thumbnail,
        post.preview?.images?.[0]?.resolutions?.slice(-1)[0]?.url,
        post.preview?.images?.[0]?.source?.url,
      ];
      return {
        id: cleanSettingText(post.name || post.id || permalink, "", 160),
        subreddit,
        title: cleanSettingText(post.title, "Untitled post", 320),
        author: cleanSettingText(post.author, "unknown", 80),
        permalink,
        createdUtc: Math.max(0, Number(post.created_utc) || 0),
        score: Math.max(0, Number(post.score) || 0),
        comments: Math.max(0, Number(post.num_comments) || 0),
        over18: post.over_18 === true || matureSubreddits.has(subreddit.toLowerCase()),
        spoiler: post.spoiler === true,
        domain: cleanSettingText(post.domain, "reddit.com", 120),
        thumbnail: imageCandidates.map(trustedRedditImage).find(Boolean) || "",
      };
    }).filter((post) => post.id && (includeNsfw || !post.over18));
    const value = {
      accountKey,
      subreddits,
      sort,
      time,
      includeNsfw,
      fetchedAt: new Date().toISOString(),
      cached: false,
      posts,
    };
    redditCache.set(cacheKey, { savedAt: Date.now(), value });
    while (redditCache.size > 40) redditCache.delete(redditCache.keys().next().value);
    redditBackoffUntil = 0;
    persistRedditCache();
    return value;
  } catch (error) {
    if (fallback) return { ...fallback.value, cached: true, stale: true, partial: fallback !== cached };
    if (error.status) throw error;
    throw vaultError("Reddit could not be reached. Check the connection and refresh shortly.", 503);
  }
}

function readSpotifyConfig() {
  try {
    return JSON.parse(fs.readFileSync(SPOTIFY_CONFIG_PATH, "utf8"));
  } catch {
    return {};
  }
}

function writeSpotifyConfig(config) {
  fs.mkdirSync(path.dirname(SPOTIFY_CONFIG_PATH), { recursive: true });
  fs.writeFileSync(SPOTIFY_CONFIG_PATH, JSON.stringify(config, null, 2), "utf8");
}

function base64Url(value) {
  return Buffer.from(value).toString("base64url");
}

async function requestBody(request, maxBytes = 32_768) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > maxBytes) throw new Error("Request too large");
    chunks.push(chunk);
  }
  if (!chunks.length) return {};
  return JSON.parse(Buffer.concat(chunks).toString("utf8"));
}

function vaultError(message, status = 400) {
  const error = new Error(message);
  error.status = status;
  return error;
}

function vaultCategoryDirectory(key) {
  const folder = VAULT_CATEGORIES[key];
  if (!folder) throw vaultError("Choose Family Photos, Family Videos, Personal Projects, or Private Vault.");
  return path.join(currentVaultRoot(), folder);
}

function ensureVault() {
  try {
    fs.mkdirSync(currentVaultRoot(), { recursive: true });
    Object.keys(VAULT_CATEGORIES).forEach((key) => {
      fs.mkdirSync(vaultCategoryDirectory(key), { recursive: true });
    });
    markIntegrationHealth("local-filesystem", "ready", "Personal Vault folders are available.");
    markApplicationHealth("files", "ready", "Personal Vault is available.");
  } catch {
    markIntegrationHealth("local-filesystem", "unavailable", "The configured Personal Vault path is unavailable.");
    markApplicationHealth("files", "unavailable", "The configured Personal Vault path is unavailable.");
    throw vaultError(`${currentVaultRoot()} is unavailable. Make sure the drive or folder is connected.`, 503);
  }
}

function safeVaultName(value) {
  const cleaned = path.basename(String(value || ""))
    .replace(/[<>:"/\\|?*\u0000-\u001F]/g, "_")
    .replace(/[. ]+$/g, "")
    .slice(0, 220);
  if (!cleaned || cleaned === "." || cleaned === "..") throw vaultError("That filename cannot be saved.");
  const reserved = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i;
  return reserved.test(cleaned) ? `_${cleaned}` : cleaned;
}

function safeVaultRelativePath(value) {
  const normalized = String(value || "").replace(/\\/g, "/");
  const parts = normalized.split("/").filter(Boolean);
  if (!parts.length || parts.some((part) => part === "." || part === "..")) {
    throw vaultError("That file path is not valid.");
  }
  return parts.map(safeVaultName).join(path.sep);
}

function resolveVaultFile(category, relativePath) {
  const directory = vaultCategoryDirectory(category);
  const resolved = path.resolve(directory, safeVaultRelativePath(relativePath));
  const boundary = path.relative(path.resolve(directory), resolved);
  if (!boundary || boundary.startsWith("..") || path.isAbsolute(boundary)) {
    throw vaultError("That file is outside the Personal Vault.", 403);
  }
  if (!fs.existsSync(resolved)) throw vaultError("That vault file was not found.", 404);
  const realDirectory = fs.realpathSync(directory);
  const realResolved = fs.realpathSync(resolved);
  const realBoundary = path.relative(realDirectory, realResolved);
  if (!realBoundary || realBoundary.startsWith("..") || path.isAbsolute(realBoundary)) {
    throw vaultError("That file is outside the Personal Vault.", 403);
  }
  return realResolved;
}

function uniqueVaultPath(directory, filename) {
  const extension = path.extname(filename);
  const stem = path.basename(filename, extension);
  let candidate = path.join(directory, filename);
  let counter = 2;
  while (fs.existsSync(candidate)) {
    candidate = path.join(directory, `${stem} (${counter})${extension}`);
    counter += 1;
  }
  return candidate;
}

function vaultMime(filename) {
  const extension = path.extname(filename).toLowerCase();
  return {
    ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".gif": "image/gif",
    ".webp": "image/webp", ".avif": "image/avif", ".heic": "image/heic", ".svg": "image/svg+xml",
    ".mp4": "video/mp4", ".mov": "video/quicktime", ".m4v": "video/x-m4v", ".webm": "video/webm",
    ".avi": "video/x-msvideo", ".mkv": "video/x-matroska", ".wmv": "video/x-ms-wmv",
    ".mp3": "audio/mpeg", ".m4a": "audio/mp4", ".wav": "audio/wav", ".ogg": "audio/ogg",
    ".pdf": "application/pdf", ".txt": "text/plain; charset=utf-8", ".md": "text/markdown; charset=utf-8",
    ".doc": "application/msword", ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".xls": "application/vnd.ms-excel", ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ".ppt": "application/vnd.ms-powerpoint", ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    ".zip": "application/zip", ".json": "application/json; charset=utf-8",
  }[extension] || "application/octet-stream";
}

function vaultFileType(mime) {
  if (mime.startsWith("image/")) return "image";
  if (mime.startsWith("video/")) return "video";
  if (mime.startsWith("audio/")) return "audio";
  return "document";
}

function vaultFileRecord(category, fullPath) {
  const directory = vaultCategoryDirectory(category);
  const stats = fs.statSync(fullPath);
  const relativePath = path.relative(directory, fullPath).split(path.sep).join("/");
  const mime = vaultMime(fullPath);
  return {
    category,
    name: path.basename(fullPath),
    relativePath,
    size: stats.size,
    modifiedAt: stats.mtime.toISOString(),
    mime,
    type: vaultFileType(mime),
    url: `/api/vault/file?category=${encodeURIComponent(category)}&path=${encodeURIComponent(relativePath)}`,
  };
}

function collectVaultFiles(category, directory, depth = 0, records = []) {
  if (depth > 5 || records.length >= 500) return records;
  const entries = fs.readdirSync(directory, { withFileTypes: true });
  for (const entry of entries) {
    if (records.length >= 500) break;
    if (entry.name.startsWith(".francis-upload-")) continue;
    const fullPath = path.join(directory, entry.name);
    if (entry.isDirectory()) collectVaultFiles(category, fullPath, depth + 1, records);
    else if (entry.isFile()) records.push(vaultFileRecord(category, fullPath));
  }
  return records;
}

function readVault(includePrivate = false) {
  ensureVault();
  const categories = Object.keys(VAULT_CATEGORIES).filter((category) => includePrivate || category !== "private");
  const files = categories
    .flatMap((category) => collectVaultFiles(category, vaultCategoryDirectory(category)))
    .sort((a, b) => b.modifiedAt.localeCompare(a.modifiedAt));
  return {
    available: true,
    root: currentVaultRoot(),
    total: files.length,
    categories: Object.entries(VAULT_CATEGORIES).filter(([id]) => includePrivate || id !== "private").map(([id, label]) => ({
      id,
      label,
      count: files.filter((file) => file.category === id).length,
    })),
    files,
  };
}

async function receiveVaultUpload(request, category, requestedName) {
  ensureVault();
  const contentLength = Number(request.headers["content-length"] || 0);
  if (contentLength > VAULT_MAX_UPLOAD_BYTES) throw vaultError("That file is larger than the 10 GB vault limit.", 413);
  const directory = vaultCategoryDirectory(category);
  const filename = safeVaultName(requestedName);
  const target = uniqueVaultPath(directory, filename);
  const temporary = path.join(directory, `.francis-upload-${crypto.randomUUID()}.tmp`);
  let size = 0;

  try {
    await new Promise((resolve, reject) => {
      const output = fs.createWriteStream(temporary, { flags: "wx" });
      const fail = (error) => {
        request.unpipe(output);
        request.resume();
        output.destroy();
        reject(error);
      };
      request.on("data", (chunk) => {
        size += chunk.length;
        if (size > VAULT_MAX_UPLOAD_BYTES) fail(vaultError("That file is larger than the 10 GB vault limit.", 413));
      });
      request.on("error", reject);
      output.on("error", reject);
      output.on("finish", resolve);
      request.pipe(output);
    });
    fs.renameSync(temporary, target);
    return vaultFileRecord(category, target);
  } catch (error) {
    try {
      if (fs.existsSync(temporary)) fs.unlinkSync(temporary);
    } catch {
      // The temporary upload will be ignored by vault listings and can be removed later.
    }
    throw error;
  }
}

function sendVaultFile(request, response, fullPath) {
  const stats = fs.statSync(fullPath);
  if (!stats.isFile()) throw vaultError("That vault file was not found.", 404);
  const mime = vaultMime(fullPath);
  const filename = path.basename(fullPath);
  const commonHeaders = {
    "Content-Type": mime,
    "Content-Disposition": `inline; filename*=UTF-8''${encodeURIComponent(filename)}`,
    "Accept-Ranges": "bytes",
    "Cache-Control": "private, max-age=60",
  };
  const range = String(request.headers.range || "").match(/^bytes=(\d*)-(\d*)$/);
  if (range) {
    const start = range[1] ? Number(range[1]) : 0;
    const end = range[2] ? Math.min(Number(range[2]), stats.size - 1) : stats.size - 1;
    if (!Number.isFinite(start) || !Number.isFinite(end) || start < 0 || start > end || start >= stats.size) {
      response.writeHead(416, { "Content-Range": `bytes */${stats.size}` });
      response.end();
      return;
    }
    response.writeHead(206, {
      ...commonHeaders,
      "Content-Range": `bytes ${start}-${end}/${stats.size}`,
      "Content-Length": end - start + 1,
    });
    if (request.method === "HEAD") response.end();
    else fs.createReadStream(fullPath, { start, end }).pipe(response);
    return;
  }
  response.writeHead(200, { ...commonHeaders, "Content-Length": stats.size });
  if (request.method === "HEAD") response.end();
  else fs.createReadStream(fullPath).pipe(response);
}

function openVaultFolder(category = "") {
  ensureVault();
  if (process.platform !== "win32") throw vaultError("Open Folder is available in the Windows package.", 501);
  const target = category ? vaultCategoryDirectory(category) : currentVaultRoot();
  const explorer = spawn("explorer.exe", [target], { detached: true, stdio: "ignore" });
  explorer.unref();
}

function openDesktopApplication(applicationId = "") {
  if (process.platform !== "win32") throw vaultError("Desktop applications are available in the Windows package.", 503);
  if (applicationId !== "spotify") throw vaultError("That desktop application is not registered.", 404);
  const application = spawn("explorer.exe", ["spotify:"], { detached: true, stdio: "ignore" });
  application.unref();
}

function escapeDocumentXml(value = "") {
  return String(value)
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function crc32(buffer) {
  let crc = 0xFFFFFFFF;
  for (const byte of buffer) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit += 1) {
      crc = (crc >>> 1) ^ ((crc & 1) ? 0xEDB88320 : 0);
    }
  }
  return (crc ^ 0xFFFFFFFF) >>> 0;
}

function zipDateTime(date = new Date()) {
  const year = Math.max(1980, date.getFullYear());
  return {
    date: ((year - 1980) << 9) | ((date.getMonth() + 1) << 5) | date.getDate(),
    time: (date.getHours() << 11) | (date.getMinutes() << 5) | Math.floor(date.getSeconds() / 2),
  };
}

function createStoredZip(files) {
  const localParts = [];
  const centralParts = [];
  const stamp = zipDateTime();
  let offset = 0;

  for (const file of files) {
    const name = Buffer.from(file.name.replace(/\\/g, "/"), "utf8");
    const data = Buffer.isBuffer(file.data) ? file.data : Buffer.from(file.data, "utf8");
    const checksum = crc32(data);
    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034B50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(0x0800, 6);
    local.writeUInt16LE(0, 8);
    local.writeUInt16LE(stamp.time, 10);
    local.writeUInt16LE(stamp.date, 12);
    local.writeUInt32LE(checksum, 14);
    local.writeUInt32LE(data.length, 18);
    local.writeUInt32LE(data.length, 22);
    local.writeUInt16LE(name.length, 26);
    local.writeUInt16LE(0, 28);
    localParts.push(local, name, data);

    const central = Buffer.alloc(46);
    central.writeUInt32LE(0x02014B50, 0);
    central.writeUInt16LE(20, 4);
    central.writeUInt16LE(20, 6);
    central.writeUInt16LE(0x0800, 8);
    central.writeUInt16LE(0, 10);
    central.writeUInt16LE(stamp.time, 12);
    central.writeUInt16LE(stamp.date, 14);
    central.writeUInt32LE(checksum, 16);
    central.writeUInt32LE(data.length, 20);
    central.writeUInt32LE(data.length, 24);
    central.writeUInt16LE(name.length, 28);
    central.writeUInt16LE(0, 30);
    central.writeUInt16LE(0, 32);
    central.writeUInt16LE(0, 34);
    central.writeUInt16LE(0, 36);
    central.writeUInt32LE(0, 38);
    central.writeUInt32LE(offset, 42);
    centralParts.push(central, name);
    offset += local.length + name.length + data.length;
  }

  const centralDirectory = Buffer.concat(centralParts);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054B50, 0);
  end.writeUInt16LE(0, 4);
  end.writeUInt16LE(0, 6);
  end.writeUInt16LE(files.length, 8);
  end.writeUInt16LE(files.length, 10);
  end.writeUInt32LE(centralDirectory.length, 12);
  end.writeUInt32LE(offset, 16);
  end.writeUInt16LE(0, 20);
  return Buffer.concat([...localParts, centralDirectory, end]);
}

function documentParagraph(text, style = "", italic = false) {
  const paragraphStyle = style ? `<w:pStyle w:val="${style}"/>` : "";
  const runStyle = italic ? "<w:rPr><w:i/><w:iCs/></w:rPr>" : "";
  const safeText = escapeDocumentXml(String(text).replace(/\t/g, "    "));
  return `<w:p><w:pPr>${paragraphStyle}</w:pPr><w:r>${runStyle}<w:t xml:space="preserve">${safeText}</w:t></w:r></w:p>`;
}

function createNotebookDocx(rawTabs, ownerName = "Francis", timezone = TIMEZONE) {
  const tabs = (Array.isArray(rawTabs) ? rawTabs : [])
    .slice(0, 50)
    .map((tab, index) => ({
      label: String(tab?.label || `Tab ${index + 1}`).trim().slice(0, 80) || `Tab ${index + 1}`,
      content: String(tab?.content || "").slice(0, 200_000),
    }));
  if (!tabs.length) tabs.push({ label: "Notes", content: "" });

  const generated = new Intl.DateTimeFormat("en-US", {
    timeZone: timezone,
    month: "long",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  }).format(new Date());
  const body = [
    documentParagraph(`${ownerName} Notebook`, "Title"),
    documentParagraph(`Exported ${generated}`, "Subtitle"),
    ...tabs.flatMap((tab) => {
      const lines = tab.content.replace(/\r\n?/g, "\n").split("\n");
      const content = tab.content.trim()
        ? lines.map((line) => documentParagraph(line || " "))
        : [documentParagraph("No notes yet.", "", true)];
      return [documentParagraph(tab.label, "Heading1"), ...content];
    }),
    `<w:sectPr><w:pgSz w:w="12240" w:h="15840"/><w:pgMar w:top="1080" w:right="1260" w:bottom="1080" w:left="1260" w:header="720" w:footer="720" w:gutter="0"/></w:sectPr>`,
  ].join("");

  const documentXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>${body}</w:body></w:document>`;
  const stylesXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:eastAsia="Calibri" w:cs="Calibri"/><w:sz w:val="22"/><w:szCs w:val="22"/><w:color w:val="29222A"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="120" w:line="300" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>
  <w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>
  <w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:basedOn w:val="Normal"/><w:next w:val="Subtitle"/><w:qFormat/><w:pPr><w:spacing w:before="0" w:after="100"/></w:pPr><w:rPr><w:rFonts w:ascii="Calibri Light" w:hAnsi="Calibri Light"/><w:b/><w:color w:val="5A1B50"/><w:sz w:val="40"/><w:szCs w:val="40"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="Subtitle"><w:name w:val="Subtitle"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:spacing w:after="220"/></w:pPr><w:rPr><w:color w:val="766A74"/><w:sz w:val="20"/><w:szCs w:val="20"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:keepNext/><w:keepLines/><w:spacing w:before="360" w:after="200"/><w:outlineLvl w:val="0"/></w:pPr><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri"/><w:b/><w:color w:val="A52877"/><w:sz w:val="32"/><w:szCs w:val="32"/></w:rPr></w:style>
</w:styles>`;
  const contentTypes = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>`;
  const packageRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>`;
  const documentRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`;
  const created = new Date().toISOString();
  const coreXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>${escapeDocumentXml(ownerName)} Notebook</dc:title><dc:creator>${escapeDocumentXml(ownerName)} Dashboard</dc:creator><cp:lastModifiedBy>${escapeDocumentXml(ownerName)} Dashboard</cp:lastModifiedBy><dcterms:created xsi:type="dcterms:W3CDTF">${created}</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">${created}</dcterms:modified></cp:coreProperties>`;
  const appXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>Francis Dashboard</Application><AppVersion>45.0</AppVersion></Properties>`;

  return createStoredZip([
    { name: "[Content_Types].xml", data: contentTypes },
    { name: "_rels/.rels", data: packageRels },
    { name: "docProps/core.xml", data: coreXml },
    { name: "docProps/app.xml", data: appXml },
    { name: "word/document.xml", data: documentXml },
    { name: "word/styles.xml", data: stylesXml },
    { name: "word/_rels/document.xml.rels", data: documentRels },
  ]);
}

async function tokenRequest(parameters) {
  const response = await fetch("https://accounts.spotify.com/api/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams(parameters),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.error_description || data.error || `Spotify token request returned ${response.status}`);
  }
  return data;
}

async function spotifyAccessToken() {
  const config = readSpotifyConfig();
  if (!config.clientId || !config.refreshToken) return null;
  if (config.accessToken && Number(config.expiresAt || 0) > Date.now() + 60_000) {
    return config.accessToken;
  }
  const token = await tokenRequest({
    grant_type: "refresh_token",
    refresh_token: config.refreshToken,
    client_id: config.clientId,
  });
  const next = {
    ...config,
    accessToken: token.access_token,
    refreshToken: token.refresh_token || config.refreshToken,
    expiresAt: Date.now() + Number(token.expires_in || 3600) * 1000,
  };
  writeSpotifyConfig(next);
  return next.accessToken;
}

async function spotifyApi(pathname, options = {}) {
  const accessToken = await spotifyAccessToken();
  if (!accessToken) {
    markIntegrationHealth("spotify", "not_configured", "Spotify has not been connected.");
    markApplicationHealth("spotify", "not_configured", "Connect Spotify to enable playback controls.");
    return { connected: false };
  }
  const response = await fetch(`https://api.spotify.com${pathname}`, {
    ...options,
    headers: {
      Authorization: `Bearer ${accessToken}`,
      ...(options.headers || {}),
    },
  });
  if (response.status === 401) {
    const config = readSpotifyConfig();
    writeSpotifyConfig({ ...config, accessToken: "", expiresAt: 0 });
    markIntegrationHealth("spotify", "degraded", "Spotify authorization needs to be refreshed.");
    markApplicationHealth("spotify", "degraded", "Spotify authorization needs attention.");
  } else if (response.ok || response.status === 204) {
    markIntegrationHealth("spotify", "ready", "Spotify playback is connected.");
    markApplicationHealth("spotify", "ready", "Spotify player is available.");
  }
  return { connected: true, response };
}

function spotifyStatus() {
  const config = readSpotifyConfig();
  return {
    configured: Boolean(config.clientId),
    connected: Boolean(config.clientId && config.refreshToken),
    redirectUri: SPOTIFY_REDIRECT_URI,
  };
}

function readGoogleCalendarConfig() {
  try {
    return JSON.parse(fs.readFileSync(GOOGLE_CALENDAR_CONFIG_PATH, "utf8"));
  } catch {
    return {};
  }
}

function writeGoogleCalendarConfig(config) {
  fs.mkdirSync(path.dirname(GOOGLE_CALENDAR_CONFIG_PATH), { recursive: true });
  fs.writeFileSync(GOOGLE_CALENDAR_CONFIG_PATH, JSON.stringify(config, null, 2), "utf8");
}

function googleCalendarStatus() {
  const config = readGoogleCalendarConfig();
  return {
    configured: Boolean(config.secretIcalUrl),
    connected: Boolean(config.secretIcalUrl),
    calendarName: String(config.calendarName || ""),
    lastSyncedAt: config.agendaCache?.fetchedAt || null,
  };
}

function timezoneOffsetMinutes(timezone, date) {
  const label = new Intl.DateTimeFormat("en-US", {
    timeZone: timezone,
    timeZoneName: "longOffset",
  }).formatToParts(date).find((part) => part.type === "timeZoneName")?.value || "GMT";
  const match = label.match(/GMT([+-])(\d{2}):?(\d{2})?/);
  if (!match) return 0;
  const minutes = Number(match[2]) * 60 + Number(match[3] || 0);
  return match[1] === "-" ? -minutes : minutes;
}

function zonedDayBoundary(timezone, dayOffset = 0) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: timezone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(new Date());
  const value = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  const guess = new Date(Date.UTC(Number(value.year), Number(value.month) - 1, Number(value.day) + dayOffset));
  const offset = timezoneOffsetMinutes(timezone, guess);
  return new Date(guess.getTime() - offset * 60_000);
}

function calendarDayKey(value, timezone) {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: timezone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date(value));
}

function stripCalendarMarkup(value = "") {
  return String(value)
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<[^>]+>/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 600);
}

function normalizeSecretIcalUrl(value) {
  const source = String(value || "").trim().replace(/^webcal:\/\//i, "https://");
  let parsed;
  try {
    parsed = new URL(source);
  } catch {
    throw new Error("Paste the complete Secret address in iCal format from Google Calendar.");
  }
  const hostname = parsed.hostname.toLowerCase();
  const isGoogle = hostname === "calendar.google.com" || hostname === "www.google.com";
  const isPrivateIcal = /\/calendar\/ical\//i.test(parsed.pathname)
    && /\/private-[^/]+\//i.test(parsed.pathname)
    && /\.ics$/i.test(parsed.pathname);
  if (parsed.protocol !== "https:" || !isGoogle || !isPrivateIcal) {
    throw new Error("Use the Secret address in iCal format, not the public or shareable calendar link.");
  }
  parsed.hash = "";
  return parsed.toString();
}

function unfoldIcal(value) {
  return String(value || "").replace(/\r?\n[ \t]/g, "").split(/\r?\n/);
}

function unescapeIcal(value = "") {
  return String(value)
    .replace(/\\[nN]/g, "\n")
    .replace(/\\,/g, ",")
    .replace(/\\;/g, ";")
    .replace(/\\\\/g, "\\")
    .trim();
}

function parseIcalProperty(line) {
  const colon = line.indexOf(":");
  if (colon < 0) return null;
  const left = line.slice(0, colon);
  const pieces = left.split(";");
  const name = pieces.shift().toUpperCase();
  const params = {};
  for (const piece of pieces) {
    const equal = piece.indexOf("=");
    if (equal < 0) continue;
    params[piece.slice(0, equal).toUpperCase()] = piece.slice(equal + 1).replace(/^"|"$/g, "");
  }
  return { name, params, value: line.slice(colon + 1) };
}

function parseIcalDocument(source) {
  const lines = unfoldIcal(source);
  const events = [];
  let event = null;
  let calendarName = "";
  let calendarTimezone = "";
  for (const line of lines) {
    if (line === "BEGIN:VEVENT") {
      event = {};
      continue;
    }
    if (line === "END:VEVENT") {
      if (event) events.push(event);
      event = null;
      continue;
    }
    const property = parseIcalProperty(line);
    if (!property) continue;
    if (!event) {
      if (property.name === "X-WR-CALNAME") calendarName = unescapeIcal(property.value);
      if (property.name === "X-WR-TIMEZONE") calendarTimezone = unescapeIcal(property.value);
      continue;
    }
    if (!event[property.name]) event[property.name] = [];
    event[property.name].push(property);
  }
  return { events, calendarName, calendarTimezone };
}

function zonedDateFromParts(timezone, year, month, day, hour = 0, minute = 0, second = 0) {
  const guess = Date.UTC(year, month - 1, day, hour, minute, second);
  let result = guess - timezoneOffsetMinutes(timezone, new Date(guess)) * 60_000;
  result = guess - timezoneOffsetMinutes(timezone, new Date(result)) * 60_000;
  return new Date(result);
}

function datePartsInZone(value, timezone) {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: timezone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23",
  }).formatToParts(value);
  const item = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return {
    year: Number(item.year),
    month: Number(item.month),
    day: Number(item.day),
    hour: Number(item.hour),
    minute: Number(item.minute),
    second: Number(item.second),
  };
}

function parseIcalDate(property, fallbackTimezone) {
  if (!property) return null;
  const raw = String(property.value || "").trim();
  const dateOnly = property.params.VALUE === "DATE" || /^\d{8}$/.test(raw);
  const match = raw.match(/^(\d{4})(\d{2})(\d{2})(?:T(\d{2})(\d{2})(\d{2})?)?(Z)?$/);
  if (!match) return null;
  const [, year, month, day, hour = "0", minute = "0", second = "0", utc] = match;
  const timezone = property.params.TZID || fallbackTimezone || TIMEZONE;
  const date = utc
    ? new Date(Date.UTC(+year, +month - 1, +day, +hour, +minute, +second))
    : zonedDateFromParts(timezone, +year, +month, +day, +hour, +minute, +second);
  return { date, allDay: dateOnly, timezone, raw };
}

function firstIcal(event, name) {
  return event[name]?.[0] || null;
}

function parseRRule(property) {
  const rule = {};
  for (const entry of String(property?.value || "").split(";")) {
    const [key, value] = entry.split("=");
    if (key && value) rule[key.toUpperCase()] = value.toUpperCase();
  }
  return rule;
}

const ICAL_WEEKDAYS = ["SU", "MO", "TU", "WE", "TH", "FR", "SA"];

function recurrenceMatches(parts, base, rule) {
  const candidateDay = Date.UTC(parts.year, parts.month - 1, parts.day);
  const baseDay = Date.UTC(base.year, base.month - 1, base.day);
  const dayDifference = Math.round((candidateDay - baseDay) / 86_400_000);
  if (dayDifference < 0) return false;
  const interval = Math.max(1, Number(rule.INTERVAL || 1));
  const weekday = ICAL_WEEKDAYS[new Date(candidateDay).getUTCDay()];
  const byDay = String(rule.BYDAY || "").split(",").filter(Boolean);
  const byMonthDay = String(rule.BYMONTHDAY || "").split(",").filter(Boolean).map(Number).filter(Number.isFinite);
  const byMonth = String(rule.BYMONTH || "").split(",").filter(Boolean).map(Number).filter(Number.isFinite);
  if (byMonth.length && !byMonth.includes(parts.month)) return false;
  if (byMonthDay.length && !byMonthDay.includes(parts.day)) return false;

  if (rule.FREQ === "DAILY") {
    if (dayDifference % interval) return false;
    return !byDay.length || byDay.some((entry) => entry.slice(-2) === weekday);
  }
  if (rule.FREQ === "WEEKLY") {
    const baseWeekday = new Date(baseDay).getUTCDay();
    const candidateWeekday = new Date(candidateDay).getUTCDay();
    const baseMonday = baseDay - ((baseWeekday + 6) % 7) * 86_400_000;
    const candidateMonday = candidateDay - ((candidateWeekday + 6) % 7) * 86_400_000;
    const weekDifference = Math.round((candidateMonday - baseMonday) / (7 * 86_400_000));
    if (weekDifference < 0 || weekDifference % interval) return false;
    return byDay.length ? byDay.some((entry) => entry.slice(-2) === weekday) : weekday === ICAL_WEEKDAYS[new Date(baseDay).getUTCDay()];
  }
  if (rule.FREQ === "MONTHLY") {
    const monthDifference = (parts.year - base.year) * 12 + parts.month - base.month;
    if (monthDifference < 0 || monthDifference % interval) return false;
    if (byDay.length) {
      const daysInMonth = new Date(Date.UTC(parts.year, parts.month, 0)).getUTCDate();
      return byDay.some((entry) => {
        if (entry.slice(-2) !== weekday) return false;
        const ordinal = Number(entry.slice(0, -2));
        if (!ordinal) return true;
        const positive = Math.floor((parts.day - 1) / 7) + 1;
        const negative = -Math.floor((daysInMonth - parts.day) / 7) - 1;
        return ordinal === positive || ordinal === negative;
      });
    }
    return byMonthDay.length ? byMonthDay.includes(parts.day) : parts.day === base.day;
  }
  if (rule.FREQ === "YEARLY") {
    const yearDifference = parts.year - base.year;
    if (yearDifference < 0 || yearDifference % interval) return false;
    if (!byMonth.length && parts.month !== base.month) return false;
    if (!byMonthDay.length && parts.day !== base.day) return false;
    return !byDay.length || byDay.some((entry) => entry.slice(-2) === weekday);
  }
  return false;
}

function occurrenceNumber(parts, base, rule) {
  const end = Date.UTC(parts.year, parts.month - 1, parts.day);
  let cursor = Date.UTC(base.year, base.month - 1, base.day);
  let count = 0;
  for (let checked = 0; cursor <= end && checked < 20_000; checked++, cursor += 86_400_000) {
    const date = new Date(cursor);
    const candidate = { year: date.getUTCFullYear(), month: date.getUTCMonth() + 1, day: date.getUTCDate() };
    if (recurrenceMatches(candidate, base, rule)) count++;
  }
  return count;
}

function icalMeetingUrl(event, description, location) {
  const explicit = unescapeIcal(firstIcal(event, "URL")?.value || "");
  const combined = `${explicit} ${location} ${description}`;
  return combined.match(/https?:\/\/(?:[^\s<>"']*\.)?(?:zoom\.us|meet\.google\.com|teams\.microsoft\.com)\/[^\s<>"']*/i)?.[0]
    || "";
}

function normalizeIcalEvent(event, startInfo, endDate, timezone, occurrenceId = "") {
  const description = stripCalendarMarkup(unescapeIcal(firstIcal(event, "DESCRIPTION")?.value || ""));
  const location = unescapeIcal(firstIcal(event, "LOCATION")?.value || "").slice(0, 220);
  const uid = unescapeIcal(firstIcal(event, "UID")?.value || crypto.randomUUID());
  const attendees = (event.ATTENDEE || []).slice(0, 30).map((attendee) => {
    const email = unescapeIcal(attendee.value || "").replace(/^mailto:/i, "");
    return {
      name: unescapeIcal(attendee.params.CN || email || "Guest").slice(0, 100),
      email: email.slice(0, 160),
      responseStatus: String(attendee.params.PARTSTAT || "NEEDS-ACTION").toLowerCase().replace("needs-action", "needsAction"),
      self: false,
    };
  });
  const explicitUrl = unescapeIcal(firstIcal(event, "URL")?.value || "");
  const start = startInfo.date;
  return {
    id: `${uid}${occurrenceId ? `-${occurrenceId}` : ""}`,
    title: unescapeIcal(firstIcal(event, "SUMMARY")?.value || "Untitled event").slice(0, 180),
    description,
    location,
    start: start.toISOString(),
    end: endDate.toISOString(),
    allDay: startInfo.allDay,
    day: calendarDayKey(start, timezone),
    status: unescapeIcal(firstIcal(event, "STATUS")?.value || "confirmed").toLowerCase(),
    htmlLink: /^https?:\/\//i.test(explicitUrl) ? explicitUrl : "https://calendar.google.com/calendar/u/0/r",
    joinUrl: icalMeetingUrl(event, description, location),
    attendees,
  };
}

function parseGoogleIcalAgenda(source, timezone) {
  const document = parseIcalDocument(source);
  const feedTimezone = document.calendarTimezone || timezone;
  const windowStart = zonedDayBoundary(timezone, 0);
  const windowEnd = zonedDayBoundary(timezone, 2);
  const overrides = new Map();
  const recurring = [];
  const standalone = [];

  for (const event of document.events) {
    const recurrence = firstIcal(event, "RECURRENCE-ID");
    const uid = unescapeIcal(firstIcal(event, "UID")?.value || "");
    if (recurrence && uid) {
      const recurrenceDate = parseIcalDate(recurrence, feedTimezone)?.date;
      if (recurrenceDate) overrides.set(`${uid}|${recurrenceDate.getTime()}`, event);
    } else if (firstIcal(event, "RRULE")) {
      recurring.push(event);
    } else {
      standalone.push(event);
    }
  }

  const events = [];
  const consumedOverrides = new Set();
  const addEvent = (event, startInfo, endDate, occurrenceId = "") => {
    if (!startInfo || !endDate || endDate <= windowStart || startInfo.date >= windowEnd) return;
    const normalized = normalizeIcalEvent(event, startInfo, endDate, timezone, occurrenceId);
    if (normalized.status !== "cancelled") events.push(normalized);
  };

  for (const event of standalone) {
    const startInfo = parseIcalDate(firstIcal(event, "DTSTART"), feedTimezone);
    if (!startInfo) continue;
    const parsedEnd = parseIcalDate(firstIcal(event, "DTEND"), startInfo.timezone);
    const defaultDuration = startInfo.allDay ? 86_400_000 : 3_600_000;
    addEvent(event, startInfo, parsedEnd?.date || new Date(startInfo.date.getTime() + defaultDuration));
  }

  for (const event of recurring) {
    const startInfo = parseIcalDate(firstIcal(event, "DTSTART"), feedTimezone);
    if (!startInfo) continue;
    const parsedEnd = parseIcalDate(firstIcal(event, "DTEND"), startInfo.timezone);
    const duration = Math.max(1, (parsedEnd?.date || new Date(startInfo.date.getTime() + (startInfo.allDay ? 86_400_000 : 3_600_000))) - startInfo.date);
    const base = datePartsInZone(startInfo.date, startInfo.timezone);
    const rule = parseRRule(firstIcal(event, "RRULE"));
    const untilInfo = rule.UNTIL ? parseIcalDate({ value: rule.UNTIL, params: {} }, startInfo.timezone) : null;
    const until = untilInfo ? untilInfo.date.getTime() + (untilInfo.allDay ? 86_399_999 : 0) : Infinity;
    const countLimit = Number(rule.COUNT || 0);
    const exclusions = new Set((event.EXDATE || []).flatMap((property) => String(property.value || "").split(",").map((value) => {
      const parsed = parseIcalDate({ value, params: property.params }, startInfo.timezone);
      return parsed?.date.getTime();
    }).filter(Number.isFinite)));
    const firstCandidate = datePartsInZone(new Date(Math.max(startInfo.date.getTime(), windowStart.getTime() - duration)), startInfo.timezone);
    const lastCandidate = datePartsInZone(windowEnd, startInfo.timezone);
    let cursor = Date.UTC(firstCandidate.year, firstCandidate.month - 1, firstCandidate.day);
    const last = Date.UTC(lastCandidate.year, lastCandidate.month - 1, lastCandidate.day);
    for (; cursor <= last; cursor += 86_400_000) {
      const cursorDate = new Date(cursor);
      const parts = { year: cursorDate.getUTCFullYear(), month: cursorDate.getUTCMonth() + 1, day: cursorDate.getUTCDate() };
      if (!recurrenceMatches(parts, base, rule)) continue;
      if (countLimit && occurrenceNumber(parts, base, rule) > countLimit) continue;
      const occurrenceStart = zonedDateFromParts(startInfo.timezone, parts.year, parts.month, parts.day, base.hour, base.minute, base.second);
      if (occurrenceStart.getTime() > until) continue;
      const uid = unescapeIcal(firstIcal(event, "UID")?.value || "");
      const overrideKey = `${uid}|${occurrenceStart.getTime()}`;
      const override = overrides.get(overrideKey);
      if (override) {
        consumedOverrides.add(overrideKey);
        const overrideStart = parseIcalDate(firstIcal(override, "DTSTART"), feedTimezone);
        if (!overrideStart) continue;
        const overrideEnd = parseIcalDate(firstIcal(override, "DTEND"), overrideStart.timezone);
        addEvent(override, overrideStart, overrideEnd?.date || new Date(overrideStart.date.getTime() + duration), String(occurrenceStart.getTime()));
      } else if (!exclusions.has(occurrenceStart.getTime())) {
        addEvent(event, { ...startInfo, date: occurrenceStart }, new Date(occurrenceStart.getTime() + duration), String(occurrenceStart.getTime()));
      }
    }
  }

  for (const [key, event] of overrides) {
    if (consumedOverrides.has(key)) continue;
    const startInfo = parseIcalDate(firstIcal(event, "DTSTART"), feedTimezone);
    if (!startInfo) continue;
    const parsedEnd = parseIcalDate(firstIcal(event, "DTEND"), startInfo.timezone);
    addEvent(event, startInfo, parsedEnd?.date || new Date(startInfo.date.getTime() + (startInfo.allDay ? 86_400_000 : 3_600_000)), key.split("|")[1]);
  }

  events.sort((left, right) => new Date(left.start) - new Date(right.start));
  return {
    calendarName: document.calendarName || "Google Calendar",
    events,
  };
}

async function fetchGoogleIcal(secretIcalUrl, timezone) {
  const response = await fetch(secretIcalUrl, {
    redirect: "follow",
    headers: {
      Accept: "text/calendar, text/plain;q=0.9",
      "User-Agent": "Francis-Dashboard-Windows/45.0",
    },
    signal: AbortSignal.timeout(15_000),
  });
  if (!response.ok) throw new Error(`Google Calendar returned ${response.status}. Check that the secret iCal address is still active.`);
  const source = await response.text();
  if (source.length > 15_000_000) throw new Error("That calendar feed is too large to load safely.");
  if (!/BEGIN:VCALENDAR/i.test(source)) throw new Error("Google did not return a valid iCal calendar. Copy the Secret address again.");
  return parseGoogleIcalAgenda(source, timezone);
}

async function readGoogleAgenda(secretIcalOverride = "") {
  const config = readGoogleCalendarConfig();
  const secretIcalUrl = secretIcalOverride || config.secretIcalUrl;
  if (!secretIcalUrl) return { connected: false, events: [] };
  const settings = readDashboardSettings();
  const timezone = settings.location.timezone || TIMEZONE;
  try {
    const parsed = await fetchGoogleIcal(secretIcalUrl, timezone);
    const today = calendarDayKey(zonedDayBoundary(timezone, 0), timezone);
    const tomorrow = calendarDayKey(zonedDayBoundary(timezone, 1), timezone);
    const agenda = {
      connected: true,
      calendarName: parsed.calendarName,
      timezone,
      today,
      tomorrow,
      fetchedAt: new Date().toISOString(),
      events: parsed.events,
      cached: false,
    };
    if (!secretIcalOverride) writeGoogleCalendarConfig({ secretIcalUrl, calendarName: agenda.calendarName, agendaCache: agenda });
    markIntegrationHealth("google-calendar", "ready", "Google Calendar refreshed successfully.");
    markApplicationHealth("calendar", "ready", "Calendar agenda is current.");
    return agenda;
  } catch (error) {
    if (!secretIcalOverride && config.agendaCache?.events) {
      markIntegrationHealth("google-calendar", "degraded", "Using the last successful Google Calendar sync.");
      markApplicationHealth("calendar", "degraded", "Calendar is showing its cached agenda.");
      return { ...config.agendaCache, connected: true, cached: true, error: error.message };
    }
    markIntegrationHealth("google-calendar", "unavailable", error.message);
    markApplicationHealth("calendar", "unavailable", "Google Calendar could not refresh.");
    throw error;
  }
}

function xmlText(value = "") {
  return value
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/<[^>]+>/g, "")
    .trim();
}

function itemValue(item, tag) {
  return xmlText(item.match(new RegExp(`<${tag}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${tag}>`, "i"))?.[1] || "");
}

function weatherLabel(code) {
  if (code === 0) return { label: "Clear sky", icon: "sun" };
  if ([1, 2].includes(code)) return { label: "Mostly sunny", icon: "partly" };
  if (code === 3) return { label: "Overcast", icon: "cloud" };
  if ([45, 48].includes(code)) return { label: "Foggy", icon: "fog" };
  if ([51, 53, 55, 56, 57].includes(code)) return { label: "Light drizzle", icon: "rain" };
  if ([61, 63, 65, 66, 67, 80, 81, 82].includes(code)) return { label: "Rain", icon: "rain" };
  if ([71, 73, 75, 77, 85, 86].includes(code)) return { label: "Snow", icon: "snow" };
  if ([95, 96, 99].includes(code)) return { label: "Thunderstorms", icon: "storm" };
  return { label: "Variable skies", icon: "partly" };
}

function compactTime(value) {
  const match = String(value).match(/T(\d{2}):(\d{2})/);
  if (!match) return "--";
  const hour = Number(match[1]);
  return `${hour % 12 || 12}:${match[2]} ${hour >= 12 ? "PM" : "AM"}`;
}

function minuteOfDay(value, fallback) {
  const match = String(value).match(/T(\d{2}):(\d{2})/);
  return match ? Number(match[1]) * 60 + Number(match[2]) : fallback;
}

async function getWeather(settings = readDashboardSettings()) {
  const location = settings.location;
  const params = new URLSearchParams({
    latitude: String(location.latitude),
    longitude: String(location.longitude),
    current: "temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,cloud_cover,wind_speed_10m,wind_direction_10m,wind_gusts_10m",
    hourly: "temperature_2m,precipitation_probability,weather_code",
    daily: "weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max,precipitation_probability_max,wind_gusts_10m_max",
    temperature_unit: "fahrenheit",
    wind_speed_unit: "mph",
    precipitation_unit: "inch",
    timezone: location.timezone,
    forecast_days: "3",
  });
  const response = await fetch(`https://api.open-meteo.com/v1/forecast?${params}`, {
    headers: { "User-Agent": "Francis-Dashboard-Windows/45.0" },
  });
  if (!response.ok) throw new Error(`Weather service returned ${response.status}`);
  const data = await response.json();
  const currentHour = data.hourly.time.findIndex((time) => time >= data.current.time.slice(0, 13) + ":00");
  const start = Math.max(0, currentHour);
  const hours = data.hourly.time.slice(start, start + 7).map((time, index) => {
    const sourceIndex = start + index;
    return {
      time: compactTime(time),
      temperature: Math.round(data.hourly.temperature_2m[sourceIndex]),
      rainChance: data.hourly.precipitation_probability[sourceIndex],
      ...weatherLabel(data.hourly.weather_code[sourceIndex]),
    };
  });
  const condition = weatherLabel(data.current.weather_code);
  const weather = {
    location: location.label,
    condition: condition.label,
    icon: condition.icon,
    temperature: Math.round(data.current.temperature_2m),
    feelsLike: Math.round(data.current.apparent_temperature),
    humidity: Math.round(data.current.relative_humidity_2m),
    windSpeed: Math.round(data.current.wind_speed_10m),
    windGust: Math.round(data.current.wind_gusts_10m),
    high: Math.round(data.daily.temperature_2m_max[0]),
    low: Math.round(data.daily.temperature_2m_min[0]),
    rainChance: Math.round(data.daily.precipitation_probability_max[0]),
    uvIndex: Math.round(data.daily.uv_index_max[0]),
    sunrise: compactTime(data.daily.sunrise[0]),
    sunset: compactTime(data.daily.sunset[0]),
    sunriseMinutes: minuteOfDay(data.daily.sunrise[0], 420),
    sunsetMinutes: minuteOfDay(data.daily.sunset[0], 1080),
    hours,
  };
  markIntegrationHealth("open-meteo", "ready", "Weather refreshed successfully.");
  markApplicationHealth("weather", "ready", "Weather information is current.");
  return weather;
}

async function getNews(settings = readDashboardSettings()) {
  const feeds = settings.newsTopics.map((topic) => ({
    category: topic.label,
    query: topic.query,
  }));
  let failures = 0;
  const items = await Promise.all(feeds.map(async (feed, index) => {
    try {
      const url = `https://news.google.com/rss/search?q=${encodeURIComponent(feed.query)}&hl=en-US&gl=US&ceid=US:en`;
      const response = await fetch(url, { headers: { "User-Agent": "Francis-Dashboard-Windows/45.0" } });
      if (!response.ok) throw new Error("Feed unavailable");
      const xml = await response.text();
      const item = xml.match(/<item>([\s\S]*?)<\/item>/i)?.[1] || "";
      const rawTitle = itemValue(item, "title");
      const title = rawTitle.replace(/\s+-\s+[^-]+$/, "");
      const published = new Date(itemValue(item, "pubDate"));
      const hours = Math.max(1, Math.floor((Date.now() - published.getTime()) / 3600000));
      return {
        id: `news-${index}`,
        category: feed.category,
        title: title || "No major headline found",
        source: itemValue(item, "source") || "Google News",
        age: Number.isFinite(hours) ? (hours < 24 ? `${hours}h ago` : `${Math.floor(hours / 24)}d ago`) : "Recent",
        url: itemValue(item, "link") || "https://news.google.com/",
      };
    } catch {
      failures += 1;
      return {
        id: `news-${index}`,
        category: feed.category,
        title: "This news feed is taking a moment",
        source: "Refresh shortly",
        age: "Now",
        url: "https://news.google.com/",
      };
    }
  }));
  if (failures === feeds.length) {
    markIntegrationHealth("google-news", "unavailable", "Google News feeds could not refresh.");
    markApplicationHealth("headlines", "degraded", "Headline cards are showing fallback messages.");
  } else if (failures > 0) {
    markIntegrationHealth("google-news", "degraded", `${failures} headline feed${failures === 1 ? "" : "s"} could not refresh.`);
    markApplicationHealth("headlines", "degraded", "Some headline cards could not refresh.");
  } else {
    markIntegrationHealth("google-news", "ready", "Google News feeds refreshed successfully.");
    markApplicationHealth("headlines", "ready", "All headline cards are current.");
  }
  return items;
}

async function getInterestFeed(channel, requestedQuery) {
  const fallbacks = {
    technology: "AI cybersecurity Microsoft gadgets consumer technology when:3d",
    gaming: "video games PlayStation Xbox Nintendo PC gaming when:3d",
    golf: "golf instruction golf equipment PGA Tour golf course architecture when:3d",
  };
  const stockImages = {
    technology: [
      "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1200&q=82",
      "https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?auto=format&fit=crop&w=1200&q=82",
      "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=82",
    ],
    gaming: [
      "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1200&q=82",
      "https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=1200&q=82",
      "https://images.unsplash.com/photo-1493711662062-fa541adb3fc8?auto=format&fit=crop&w=1200&q=82",
    ],
    golf: [
      "https://images.unsplash.com/photo-1535131749006-b7f58c99034b?auto=format&fit=crop&w=1200&q=82",
      "https://images.unsplash.com/photo-1587174486073-ae5e5cff23aa?auto=format&fit=crop&w=1200&q=82",
      "https://images.unsplash.com/photo-1593111774240-d529f12cf4bb?auto=format&fit=crop&w=1200&q=82",
    ],
  };
  const fallback = fallbacks[channel] || fallbacks.technology;
  const cleanQuery = cleanSettingText(requestedQuery, fallback, 180);
  const query = /\bwhen:\d+[hd]\b/i.test(cleanQuery) ? cleanQuery : `${cleanQuery} when:3d`;
  const feedUrl = `${GOOGLE_NEWS_BASE}?q=${encodeURIComponent(query)}&hl=en-US&gl=US&ceid=US:en`;
  const feedResponse = await fetch(feedUrl, {
    headers: { "User-Agent": "Francis-Dashboard-Windows/45.0" },
  });
  if (!feedResponse.ok) throw new Error(`Interest feed returned ${feedResponse.status}`);
  const xml = await feedResponse.text();
  const items = [...xml.matchAll(/<item>([\s\S]*?)<\/item>/gi)].slice(0, 5).map((match, index) => {
    const item = match[1];
    const rawTitle = itemValue(item, "title");
    const published = new Date(itemValue(item, "pubDate"));
    const elapsedHours = Math.max(1, Math.floor((Date.now() - published.getTime()) / 3600000));
    const embeddedImage = [
      item.match(/<media:(?:content|thumbnail)\b[^>]*\burl=["']([^"']+)["']/i)?.[1],
      item.match(/<enclosure\b[^>]*\btype=["']image\/[^"']+["'][^>]*\burl=["']([^"']+)["']/i)?.[1],
      item.match(/<enclosure\b[^>]*\burl=["']([^"']+)["'][^>]*\btype=["']image\/[^"']+["']/i)?.[1],
      item.match(/<description(?:\s[^>]*)?>[\s\S]*?<img\b[^>]*\bsrc=["']([^"']+)["']/i)?.[1],
    ].find(Boolean);
    const decodedImage = String(embeddedImage || "")
      .replace(/&amp;/g, "&")
      .replace(/&quot;/g, '"')
      .replace(/&#39;|&apos;/g, "'");
    const image = /^https?:\/\//i.test(decodedImage)
      ? decodedImage
      : stockImages[channel]?.[index % stockImages[channel].length] || "";
    return {
      id: `${channel}-${index}-${published.getTime() || Date.now()}`,
      title: cleanSettingText(rawTitle.replace(/\s+-\s+[^-]+$/, ""), "Untitled story", 320),
      source: cleanSettingText(itemValue(item, "source"), "Google News", 120),
      age: Number.isFinite(elapsedHours)
        ? (elapsedHours < 24 ? `${elapsedHours}h ago` : `${Math.floor(elapsedHours / 24)}d ago`)
        : "Recent",
      url: itemValue(item, "link") || "https://news.google.com/",
      image,
    };
  });
  markIntegrationHealth("google-news", "ready", "Public news feeds refreshed successfully.");
  markApplicationHealth("interest-hub", "ready", `${channel} stories refreshed successfully.`);
  return items;
}

async function searchLocations(query) {
  const params = new URLSearchParams({
    name: query,
    count: "6",
    language: "en",
    format: "json",
  });
  const response = await fetch(`https://geocoding-api.open-meteo.com/v1/search?${params}`, {
    headers: { "User-Agent": "Francis-Dashboard-Windows/45.0" },
  });
  if (!response.ok) throw new Error(`Location search returned ${response.status}`);
  const data = await response.json();
  return (data.results || []).map((result) => {
    const region = result.admin1 || result.country;
    return {
      label: [result.name, region].filter(Boolean).join(", "),
      detail: [result.country, result.timezone].filter(Boolean).join(" · "),
      latitude: result.latitude,
      longitude: result.longitude,
      timezone: result.timezone || TIMEZONE,
    };
  });
}

function fallbackWeather(settings = readDashboardSettings()) {
  return {
    location: settings.location.label,
    condition: "Weather unavailable",
    icon: "partly",
    temperature: "--",
    feelsLike: "--",
    humidity: "--",
    windSpeed: "--",
    windGust: "--",
    high: "--",
    low: "--",
    rainChance: "--",
    uvIndex: "--",
    sunrise: "--",
    sunset: "--",
    sunriseMinutes: 420,
    sunsetMinutes: 1080,
    hours: [],
  };
}

async function buildMorning() {
  const settings = readDashboardSettings();
  const timezone = settings.location.timezone || TIMEZONE;
  const now = new Date();
  const hour = Number(new Intl.DateTimeFormat("en-US", { timeZone: timezone, hour: "numeric", hour12: false }).format(now));
  let weather;
  try {
    weather = await getWeather(settings);
  } catch (error) {
    console.error("Weather refresh failed:", error.message);
    markIntegrationHealth("open-meteo", "unavailable", error.message);
    markApplicationHealth("weather", "degraded", "Weather is showing its offline fallback.");
    weather = fallbackWeather(settings);
  }
  return {
    version: APP_VERSION,
    greeting: `${hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening"}, ${settings.name}`,
    dateLabel: new Intl.DateTimeFormat("en-US", {
      timeZone: timezone,
      weekday: "long",
      month: "long",
      day: "numeric",
    }).format(now),
    updatedAt: new Intl.DateTimeFormat("en-US", {
      timeZone: timezone,
      hour: "numeric",
      minute: "2-digit",
    }).format(now),
    weather,
    news: await getNews(settings),
  };
}

const server = http.createServer(async (request, response) => {
  try {
    const url = new URL(request.url, `http://${request.headers.host}`);
    if (url.pathname === "/system-foundation-browser.js" && request.method === "GET") {
      response.writeHead(200, {
        "Content-Type": "text/javascript; charset=utf-8",
        "Cache-Control": "no-store",
      });
      fs.createReadStream(path.join(APP_ROOT, "system-foundation-browser.js")).pipe(response);
      return;
    }
    if (url.pathname === "/api/system/registry" && request.method === "GET") {
      json(response, 200, buildCurrentSystemRegistry(url.searchParams.get("workspace") || "work"));
      return;
    }
    if (url.pathname === "/api/system/health" && request.method === "GET") {
      const registry = buildCurrentSystemRegistry(url.searchParams.get("workspace") || "work");
      const applications = Object.fromEntries(registry.applications.map((item) => [item.applicationId, item.health]));
      const integrations = Object.fromEntries(registry.integrations.map((item) => [item.integrationId, item.health]));
      json(response, 200, {
        appVersion: APP_VERSION,
        registryVersion: REGISTRY_VERSION,
        schemas: registry.schemas,
        applications,
        integrations,
        storageLocations: registry.storageLocations,
      });
      return;
    }
    if (url.pathname === "/api/settings" && request.method === "GET") {
      json(response, 200, readDashboardSettings());
      return;
    }
    if (url.pathname === "/api/settings" && request.method === "POST") {
      json(response, 200, writeDashboardSettings(await requestBody(request, 65_536)));
      return;
    }
    if (url.pathname === "/api/folder-picker" && request.method === "POST") {
      const body = await requestBody(request);
      const purpose = body.purpose === "notes" ? "notes" : "storage";
      const description = purpose === "notes"
        ? "Choose where Francis Dashboard should save notebook exports"
        : "Choose the main storage folder for Francis Dashboard";
      const selectedPath = await pickWindowsFolder(body.initialPath, description);
      json(response, 200, selectedPath ? { path: selectedPath, cancelled: false } : { path: "", cancelled: true });
      return;
    }
    if (url.pathname === "/api/location-search" && request.method === "GET") {
      const query = String(url.searchParams.get("q") || "").trim();
      if (query.length < 2) throw vaultError("Type at least two letters to search for a location.");
      json(response, 200, { results: await searchLocations(query.slice(0, 100)) });
      return;
    }
    if (url.pathname === "/api/private-session" && request.method === "POST") {
      const body = await requestBody(request);
      const token = String(body.token || "");
      if (!/^[A-Za-z0-9_-]{32,160}$/.test(token)) throw vaultError("Private session could not be opened.", 400);
      privateSessions.set(token, Date.now() + 10 * 60_000);
      json(response, 200, { ok: true, expiresIn: 600 });
      return;
    }
    if (url.pathname === "/api/private-session" && request.method === "DELETE") {
      privateSessions.delete(String(url.searchParams.get("token") || ""));
      json(response, 200, { ok: true });
      return;
    }
    if (url.pathname === "/api/vault" && request.method === "GET") {
      const privateAccess = validPrivateSession(url.searchParams.get("privateToken"));
      json(response, 200, readVault(privateAccess));
      return;
    }
    if (url.pathname === "/api/vault/upload" && request.method === "POST") {
      const category = String(url.searchParams.get("category") || "");
      if (category === "private" && !validPrivateSession(url.searchParams.get("privateToken"))) {
        throw vaultError("Unlock the Private space before adding private files.", 401);
      }
      const file = await receiveVaultUpload(
        request,
        category,
        String(url.searchParams.get("name") || ""),
      );
      json(response, 201, { ok: true, file });
      return;
    }
    if (url.pathname === "/api/vault/file" && (request.method === "GET" || request.method === "HEAD")) {
      const category = String(url.searchParams.get("category") || "");
      if (category === "private" && !validPrivateSession(url.searchParams.get("privateToken"))) {
        throw vaultError("Unlock the Private space to open this file.", 401);
      }
      const fullPath = resolveVaultFile(
        category,
        String(url.searchParams.get("path") || ""),
      );
      sendVaultFile(request, response, fullPath);
      return;
    }
    if (url.pathname === "/api/vault/open-folder" && request.method === "POST") {
      const category = String(url.searchParams.get("category") || "");
      if (category === "private" && !validPrivateSession(url.searchParams.get("privateToken"))) {
        throw vaultError("Unlock the Private space before opening its folder.", 401);
      }
      openVaultFolder(category);
      json(response, 200, { ok: true });
      return;
    }
    if (url.pathname === "/api/application/open" && request.method === "POST") {
      openDesktopApplication(String(url.searchParams.get("application") || ""));
      json(response, 200, { ok: true });
      return;
    }
    if (url.pathname === "/api/bluesky/connect" && request.method === "POST") {
      const body = await requestBody(request);
      if (!validPrivateSession(body.privateToken)) {
        throw vaultError("Unlock the Private space before connecting Bluesky.", 401);
      }
      json(response, 200, { session: await connectBluesky(body.identifier, body.appPassword) });
      return;
    }
    if (url.pathname === "/api/bluesky/feed" && request.method === "POST") {
      const body = await requestBody(request, 1_000_000);
      if (!validPrivateSession(body.privateToken)) {
        throw vaultError("Unlock the Private space before loading Bluesky.", 401);
      }
      json(response, 200, await readBlueskyFeed(body));
      return;
    }
    if (url.pathname === "/api/notebook/export" && request.method === "POST") {
      const body = await requestBody(request, 1_500_000);
      const settings = readDashboardSettings();
      const document = createNotebookDocx(body.tabs, settings.name, settings.location.timezone);
      if (body.saveToFolder === true) {
        const exportRoot = settings.notesExportPath;
        if (!exportRoot) throw vaultError("Choose a notebook export folder in Settings first.");
        fs.mkdirSync(exportRoot, { recursive: true });
        const filename = notebookExportFilename(settings.name);
        const exportPath = path.join(exportRoot, filename);
        fs.writeFileSync(exportPath, document);
        json(response, 200, { saved: true, path: exportPath, filename });
        return;
      }
      response.writeHead(200, {
        "Content-Type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "Content-Disposition": 'attachment; filename="dashboard-notebook.docx"',
        "Content-Length": document.length,
        "Cache-Control": "no-store",
      });
      response.end(document);
      return;
    }
    if (url.pathname === "/api/google-calendar/status" && request.method === "GET") {
      json(response, 200, googleCalendarStatus());
      return;
    }
    if (url.pathname === "/api/google-calendar/configure" && request.method === "POST") {
      const body = await requestBody(request);
      let secretIcalUrl;
      try {
        secretIcalUrl = normalizeSecretIcalUrl(body.secretIcalUrl);
      } catch (error) {
        json(response, 400, { error: error.message });
        return;
      }
      try {
        const agenda = await readGoogleAgenda(secretIcalUrl);
        writeGoogleCalendarConfig({
          secretIcalUrl,
          calendarName: agenda.calendarName,
          agendaCache: agenda,
        });
        json(response, 200, { ok: true, calendarName: agenda.calendarName, eventCount: agenda.events.length });
      } catch (error) {
        json(response, 400, { error: error.message });
      }
      return;
    }
    if (url.pathname === "/api/google-calendar/agenda" && request.method === "GET") {
      json(response, 200, await readGoogleAgenda());
      return;
    }
    if (url.pathname === "/api/google-calendar/disconnect" && request.method === "POST") {
      writeGoogleCalendarConfig({});
      markIntegrationHealth("google-calendar", "not_configured", "Google Calendar has not been connected.");
      markApplicationHealth("calendar", "not_configured", "Connect Google Calendar to load the Work agenda.");
      json(response, 200, { ok: true });
      return;
    }
    if (url.pathname === "/api/reddit/status" && request.method === "GET") {
      json(response, 200, redditStatus());
      return;
    }
    if (url.pathname === "/api/reddit/configure" && request.method === "POST") {
      const body = await requestBody(request);
      const clientId = String(body.clientId || "").trim();
      if (!/^[A-Za-z0-9_-]{8,64}$/.test(clientId)) {
        json(response, 400, { error: "Paste the Client ID from your Reddit installed app." });
        return;
      }
      const state = base64Url(crypto.randomBytes(24));
      const existing = readRedditConfig();
      writeRedditConfig({
        ...existing,
        clientId,
        oauthState: state,
        oauthStartedAt: Date.now(),
      });
      const authorize = new URL("/api/v1/authorize", REDDIT_AUTH_BASE);
      authorize.search = new URLSearchParams({
        client_id: clientId,
        response_type: "code",
        state,
        redirect_uri: REDDIT_REDIRECT_URI,
        duration: "permanent",
        scope: REDDIT_SCOPES,
      }).toString();
      json(response, 200, { authorizeUrl: authorize.toString() });
      return;
    }
    if (url.pathname === "/reddit/callback" && request.method === "GET") {
      const config = readRedditConfig();
      const returnedState = Buffer.from(url.searchParams.get("state") || "");
      const expectedState = Buffer.from(String(config.oauthState || ""));
      const stateMatches = returnedState.length > 0
        && returnedState.length === expectedState.length
        && crypto.timingSafeEqual(returnedState, expectedState);
      const recent = Date.now() - Number(config.oauthStartedAt || 0) < 10 * 60_000;
      if (url.searchParams.get("error")) {
        response.writeHead(302, { Location: `http://localhost:${PORT}/?reddit=cancelled` });
        response.end();
        return;
      }
      if (!stateMatches || !recent || !config.clientId || !url.searchParams.get("code")) {
        response.writeHead(302, { Location: `http://localhost:${PORT}/?reddit=failed` });
        response.end();
        return;
      }
      const token = await redditTokenRequest(config.clientId, {
        grant_type: "authorization_code",
        code: url.searchParams.get("code"),
        redirect_uri: REDDIT_REDIRECT_URI,
      });
      writeRedditConfig({
        clientId: config.clientId,
        accessToken: token.access_token,
        refreshToken: token.refresh_token,
        expiresAt: Date.now() + Number(token.expires_in || 3600) * 1000,
        scope: token.scope || REDDIT_SCOPES,
      });
      clearRedditCache();
      let username = "";
      try {
        const identity = await redditApi("/api/v1/me");
        username = cleanSettingText(identity?.name, "", 80);
      } catch {
        // The read-only feed still works if Reddit does not return profile identity.
      }
      if (username) {
        const connected = readRedditConfig();
        writeRedditConfig({ ...connected, username });
      }
      response.writeHead(302, { Location: `http://localhost:${PORT}/?reddit=connected` });
      response.end();
      return;
    }
    if (url.pathname === "/api/reddit/disconnect" && request.method === "POST") {
      const existing = readRedditConfig();
      writeRedditConfig(existing.clientId ? { clientId: existing.clientId } : {});
      clearRedditCache();
      json(response, 200, { ok: true });
      return;
    }
    if (url.pathname === "/api/reddit" && request.method === "GET") {
      json(response, 200, await readRedditFeed({
        subreddits: url.searchParams.get("subreddits") || "",
        sort: url.searchParams.get("sort") || "hot",
        time: url.searchParams.get("time") || "day",
        includeNsfw: url.searchParams.get("includeNsfw") === "true",
        matureSubreddits: url.searchParams.get("matureSubreddits") || "",
        limit: url.searchParams.get("limit") || 40,
      }));
      return;
    }
    if (url.pathname === "/api/spotify/status" && request.method === "GET") {
      json(response, 200, spotifyStatus());
      return;
    }
    if (url.pathname === "/api/spotify/configure" && request.method === "POST") {
      const body = await requestBody(request);
      const clientId = String(body.clientId || "").trim();
      if (!/^[A-Za-z0-9]{16,64}$/.test(clientId)) {
        json(response, 400, { error: "Paste the Client ID from your Spotify developer app." });
        return;
      }
      const verifier = base64Url(crypto.randomBytes(64));
      const challenge = base64Url(crypto.createHash("sha256").update(verifier).digest());
      const state = base64Url(crypto.randomBytes(24));
      const existing = readSpotifyConfig();
      writeSpotifyConfig({
        ...existing,
        clientId,
        oauthState: state,
        codeVerifier: verifier,
        oauthStartedAt: Date.now(),
      });
      const authorize = new URL("https://accounts.spotify.com/authorize");
      authorize.search = new URLSearchParams({
        client_id: clientId,
        response_type: "code",
        redirect_uri: SPOTIFY_REDIRECT_URI,
        scope: SPOTIFY_SCOPES,
        code_challenge_method: "S256",
        code_challenge: challenge,
        state,
        show_dialog: "true",
      }).toString();
      json(response, 200, { authorizeUrl: authorize.toString() });
      return;
    }
    if (url.pathname === "/spotify/callback" && request.method === "GET") {
      const config = readSpotifyConfig();
      const returnedState = Buffer.from(url.searchParams.get("state") || "");
      const expectedState = Buffer.from(String(config.oauthState || ""));
      const stateMatches = returnedState.length > 0
        && returnedState.length === expectedState.length
        && crypto.timingSafeEqual(returnedState, expectedState);
      const recent = Date.now() - Number(config.oauthStartedAt || 0) < 10 * 60_000;
      if (url.searchParams.get("error")) {
        response.writeHead(302, { Location: `http://localhost:${PORT}/?spotify=cancelled` });
        response.end();
        return;
      }
      if (!stateMatches || !recent || !config.clientId || !config.codeVerifier || !url.searchParams.get("code")) {
        response.writeHead(302, { Location: `http://localhost:${PORT}/?spotify=failed` });
        response.end();
        return;
      }
      const token = await tokenRequest({
        client_id: config.clientId,
        grant_type: "authorization_code",
        code: url.searchParams.get("code"),
        redirect_uri: SPOTIFY_REDIRECT_URI,
        code_verifier: config.codeVerifier,
      });
      writeSpotifyConfig({
        clientId: config.clientId,
        accessToken: token.access_token,
        refreshToken: token.refresh_token,
        expiresAt: Date.now() + Number(token.expires_in || 3600) * 1000,
      });
      response.writeHead(302, { Location: `http://localhost:${PORT}/?spotify=connected` });
      response.end();
      return;
    }
    if (url.pathname === "/api/spotify/player" && request.method === "GET") {
      const result = await spotifyApi("/v1/me/player");
      if (!result.connected) {
        json(response, 200, { connected: false });
        return;
      }
      if (result.response.status === 204) {
        json(response, 200, { connected: true, active: false });
        return;
      }
      if (!result.response.ok) {
        const detail = await result.response.json().catch(() => ({}));
        json(response, result.response.status, {
          error: detail.error?.message || `Spotify returned ${result.response.status}`,
        });
        return;
      }
      const player = await result.response.json();
      const item = player.item;
      json(response, 200, {
        connected: true,
        active: Boolean(item),
        isPlaying: Boolean(player.is_playing),
        progressMs: Number(player.progress_ms || 0),
        durationMs: Number(item?.duration_ms || 0),
        device: player.device ? {
          name: player.device.name,
          type: player.device.type,
        } : null,
        track: item ? {
          name: item.name || "Unknown track",
          artist: (item.artists || []).map((artist) => artist.name).join(", ") || item.show?.name || "Spotify",
          image: item.album?.images?.[0]?.url || item.images?.[0]?.url || "",
          url: item.external_urls?.spotify || "https://open.spotify.com/",
        } : null,
      });
      return;
    }
    if (url.pathname === "/api/spotify/control" && request.method === "POST") {
      const body = await requestBody(request);
      const routes = {
        next: { path: "/v1/me/player/next", method: "POST" },
        previous: { path: "/v1/me/player/previous", method: "POST" },
        play: { path: "/v1/me/player/play", method: "PUT" },
        pause: { path: "/v1/me/player/pause", method: "PUT" },
      };
      const route = routes[body.action];
      if (!route) {
        json(response, 400, { error: "Unknown Spotify control." });
        return;
      }
      const result = await spotifyApi(route.path, { method: route.method });
      if (!result.connected) {
        json(response, 401, { error: "Connect Spotify first." });
        return;
      }
      if (!result.response.ok && result.response.status !== 204) {
        const detail = await result.response.json().catch(() => ({}));
        json(response, result.response.status, {
          error: detail.error?.message || "Spotify could not control the current player.",
        });
        return;
      }
      json(response, 200, { ok: true });
      return;
    }
    if (url.pathname === "/api/spotify/disconnect" && request.method === "POST") {
      const config = readSpotifyConfig();
      writeSpotifyConfig({ clientId: config.clientId || "" });
      markIntegrationHealth("spotify", "not_configured", "Spotify has not been connected.");
      markApplicationHealth("spotify", "not_configured", "Connect Spotify to enable playback controls.");
      json(response, 200, { ok: true });
      return;
    }
    if (url.pathname === "/api/interests" && request.method === "GET") {
      const requestedChannel = url.searchParams.get("channel");
      const channel = ["technology", "gaming", "golf"].includes(requestedChannel) ? requestedChannel : "technology";
      try {
        const items = await getInterestFeed(channel, url.searchParams.get("q") || "");
        json(response, 200, { channel, items, fetchedAt: new Date().toISOString() });
      } catch (error) {
        markIntegrationHealth("google-news", "unavailable", error.message);
        markApplicationHealth("interest-hub", "degraded", `${channel} stories could not refresh.`);
        throw error;
      }
      return;
    }
    if (url.pathname === "/api/morning") {
      json(response, 200, await buildMorning());
      return;
    }
    if (url.pathname === "/api/version") {
      response.writeHead(200, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
      response.end(JSON.stringify({
        version: APP_VERSION,
        port: PORT,
        registryVersion: REGISTRY_VERSION,
        schemas: {
          settings: SETTINGS_SCHEMA_VERSION,
          browser: BROWSER_SCHEMA_VERSION,
        },
      }));
      return;
    }
    if (url.pathname === "/" || url.pathname === "/index.html") {
      response.writeHead(200, {
        "Content-Type": "text/html; charset=utf-8",
        "Cache-Control": "no-store",
      });
      fs.createReadStream(path.join(APP_ROOT, "dashboard.html")).pipe(response);
      return;
    }
    response.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
    response.end("Not found");
  } catch (error) {
    console.error(error);
    const status = Number(error.status) || 500;
    response.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
    response.end(JSON.stringify({
      error: status < 500 || status === 503 ? error.message : "The dashboard could not complete that request.",
    }));
  }
});

if (require.main === module) {
  server.listen(PORT, "127.0.0.1", () => {
    console.log(`Francis Morning Dashboard ready at http://localhost:${PORT}/`);
  });
}

module.exports = {
  server,
  normalizeSecretIcalUrl,
  parseGoogleIcalAgenda,
  parseIcalDate,
  parseRRule,
  recurrenceMatches,
  zonedDayBoundary,
  normalizeSubreddits,
  normalizeRedditAtomPost,
  readRedditFeed,
};
