$ErrorActionPreference = "Stop"

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$owner = New-Object System.Windows.Forms.Form
$owner.Text = "Francis Dashboard"
$owner.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen
$owner.Size = New-Object System.Drawing.Size(1, 1)
$owner.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedToolWindow
$owner.ShowInTaskbar = $false
$owner.TopMost = $true
$owner.Opacity = 0

$dialog = New-Object System.Windows.Forms.FolderBrowserDialog
$dialog.Description = $env:DASHBOARD_PICKER_DESCRIPTION
$dialog.ShowNewFolderButton = $true

if (
  $env:DASHBOARD_PICKER_INITIAL -and
  (Test-Path -LiteralPath $env:DASHBOARD_PICKER_INITIAL -PathType Container)
) {
  $dialog.SelectedPath = $env:DASHBOARD_PICKER_INITIAL
}

try {
  $owner.Show()
  $owner.Activate()
  [System.Windows.Forms.Application]::DoEvents()

  $result = $dialog.ShowDialog($owner)
  if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
    [Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
    [Console]::Write($dialog.SelectedPath)
  }
} finally {
  $dialog.Dispose()
  $owner.Close()
  $owner.Dispose()
}
