const assert = require("node:assert/strict");
const fs = require("node:fs");
const http = require("node:http");
const os = require("node:os");
const path = require("node:path");
const vm = require("node:vm");
const { spawn } = require("node:child_process");
const {
  APP_VERSION,
  REGISTRY_VERSION,
  SETTINGS_SCHEMA_VERSION,
  BROWSER_SCHEMA_VERSION,
  migrateVersionedData,
  migrateDashboardSettings,
  buildRegistry,
  validateRegistry,
} = require("./system-foundation.cjs");

const root = fs.mkdtempSync(path.join(os.tmpdir(), "francis-v44-"));
const settingsPath = path.join(root, "settings.json");
const spotifyPath = path.join(root, "spotify.json");
const calendarPath = path.join(root, "calendar.json");
const vaultPath = path.join(root, "vault");
const mockPort = 4187;
const rssItems = Array.from({ length: 7 }, (_, index) =>
  `<item><title>${index === 0 ? "Premium dashboard technology story" : `Visual story ${index + 1}`} - Test Source</title><link>https://example.com/story-${index + 1}</link><pubDate>${new Date().toUTCString()}</pubDate><source>Test Source</source></item>`
).join("");
const rss = `<?xml version="1.0"?><rss><channel>${rssItems}</channel></rss>`;

const mockNews = http.createServer(async (request, response) => {
  const url = new URL(request.url, `http://127.0.0.1:${mockPort}`);
  const send = (status, value) => {
    response.writeHead(status, { "Content-Type": "application/json" });
    response.end(JSON.stringify(value));
  };
  if (url.pathname === "/xrpc/com.atproto.server.createSession") {
    const chunks = [];
    for await (const chunk of request) chunks.push(chunk);
    const body = JSON.parse(Buffer.concat(chunks).toString("utf8"));
    assert.equal(body.identifier, "francis.bsky.social");
    assert.equal(body.password, "app-pass-test");
    send(200, {
      accessJwt: "access-token",
      refreshJwt: "refresh-token",
      did: "did:plc:francis",
      handle: "francis.bsky.social",
    });
    return;
  }
  if (url.pathname === "/xrpc/app.bsky.feed.searchPosts") {
    send(200, { posts: [
      {
        uri: "at://did:plc:author/app.bsky.feed.post/safe",
        cid: "safe",
        author: { did: "did:plc:author", handle: "author.bsky.social", displayName: "Author", avatar: "https://cdn.bsky.app/avatar.jpg" },
        record: { text: "A safe image post", createdAt: new Date().toISOString() },
        embed: { images: [{ thumb: "https://cdn.bsky.app/thumb.jpg", fullsize: "https://cdn.bsky.app/full.jpg", alt: "Test" }] },
        labels: [],
        likeCount: 7,
      },
      {
        uri: "at://did:plc:author/app.bsky.feed.post/adult",
        cid: "adult",
        author: { did: "did:plc:author", handle: "author.bsky.social", displayName: "Author" },
        record: { text: "Properly labeled adult post", createdAt: new Date().toISOString() },
        embed: { images: [{ thumb: "https://cdn.bsky.app/adult.jpg", fullsize: "https://cdn.bsky.app/adult-full.jpg", alt: "" }] },
        labels: [{ val: "porn" }],
      },
    ] });
    return;
  }
  response.writeHead(200, { "Content-Type": "application/rss+xml" });
  response.end(rss);
});

async function waitForDashboard() {
  for (let attempt = 0; attempt < 40; attempt += 1) {
    try {
      const response = await fetch("http://127.0.0.1:4175/api/version");
      if (response.ok) return;
    } catch {}
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  throw new Error("Dashboard did not start");
}

function launchDashboard() {
  return spawn(process.execPath, ["server.cjs"], {
    cwd: __dirname,
    env: {
      ...process.env,
      LOCALAPPDATA: root,
      DASHBOARD_SETTINGS_PATH: settingsPath,
      SPOTIFY_CONFIG_PATH: spotifyPath,
      GOOGLE_CALENDAR_CONFIG_PATH: calendarPath,
      GOOGLE_NEWS_BASE: `http://127.0.0.1:${mockPort}/rss`,
      BLUESKY_SERVICE_BASE: `http://127.0.0.1:${mockPort}`,
      FRANCIS_VAULT_ROOT: vaultPath,
    },
    stdio: ["ignore", "pipe", "pipe"],
  });
}

function stopDashboard(processHandle) {
  if (!processHandle || processHandle.exitCode !== null) return Promise.resolve();
  return new Promise((resolve) => {
    processHandle.once("exit", resolve);
    processHandle.kill();
  });
}

function browserStorageFixture(initial = {}) {
  const values = new Map(Object.entries(initial));
  return {
    getItem(key) {
      return values.has(key) ? values.get(key) : null;
    },
    setItem(key, value) {
      values.set(key, String(value));
    },
    removeItem(key) {
      values.delete(key);
    },
    values,
  };
}

function validateFoundationPrimitives() {
  const legacy = {
    version: 1,
    name: "Francis",
    location: { label: "Austin, Texas" },
    defaults: { themeMode: "auto" },
  };
  const migration = migrateDashboardSettings(legacy);
  assert.equal(migration.changed, true);
  assert.equal(migration.fromVersion, 0);
  assert.equal(migration.toVersion, SETTINGS_SCHEMA_VERSION);
  assert.equal(migration.value.name, legacy.name);
  assert.deepEqual(migration.value.location, legacy.location);
  assert.deepEqual(migration.value.defaults, legacy.defaults);
  assert.equal(migration.value.systemMeta.migratedByAppVersion, APP_VERSION);

  const futureExample = migrateVersionedData({ schemaVersion: 0, value: "kept" }, {
    currentVersion: 2,
    migrations: [
      { id: "one", from: 0, to: 1, up: (value) => ({ ...value, first: true }) },
      { id: "two", from: 1, to: 2, up: (value) => ({ ...value, second: true }) },
    ],
  });
  assert.equal(futureExample.value.value, "kept");
  assert.equal(futureExample.value.first, true);
  assert.equal(futureExample.value.second, true);
  assert.equal(futureExample.applied.length, 2);
  assert.throws(() => migrateVersionedData({ schemaVersion: 3 }, {
    currentVersion: 2,
    migrations: [],
  }), /newer than supported/);

  const registry = buildRegistry();
  assert.equal(validateRegistry(registry), true);
  assert.equal(registry.appVersion, APP_VERSION);
  assert.equal(registry.registryVersion, REGISTRY_VERSION);
  assert.equal(registry.workspaces.length, 3);
  assert.ok(registry.applications.length >= 16);

  const browserSource = fs.readFileSync(path.join(__dirname, "system-foundation-browser.js"), "utf8");
  const preservedValues = {
    "morning-links": JSON.stringify([{ label: "Keep Link", url: "https://example.com" }]),
    "morning-countdowns": JSON.stringify([{ label: "Keep Date", date: "2030-01-01" }]),
    "dashboard-theme-mode": "night",
    "morning-background-hue": "218",
    "morning-youtube-id": "jfKfPfyJRdk",
    "dashboard-vault-view": "projects",
    "dashboard-notebook-v1": JSON.stringify({ activeId: "calls", tabs: [{ id: "calls", label: "Call Notes", content: "Keep me." }] }),
    "dashboard-call-notes": "Keep legacy notes.",
    "dashboard-scenes-v1": JSON.stringify({ version: 2, active: "personal", profiles: { personal: { hue: 18 } } }),
    "dashboard-interest-hub-v1": JSON.stringify({ technology: "AI", gaming: "Nintendo", golf: "PGA Tour" }),
    "dashboard-reddit-v1": JSON.stringify({ version: 2, subreddits: ["technology"] }),
    "dashboard-private-space-v1": JSON.stringify({ version: 1, data: "encrypted-fixture" }),
  };
  const preservedScene = preservedValues["dashboard-scenes-v1"];
  const storage = browserStorageFixture(preservedValues);
  const window = { localStorage: storage };
  vm.runInNewContext(browserSource, { window, Date, JSON, Object, Error, Number, Array });
  const boot = window.FrancisSystemFoundation.boot({ storage });
  assert.equal(boot.browserSchemaVersion, BROWSER_SCHEMA_VERSION);
  for (const [key, value] of Object.entries(preservedValues)) {
    assert.equal(storage.getItem(key), value, `${key} changed during the V44 migration`);
  }
  assert.equal(JSON.parse(storage.getItem("francis-os-system-state-v1")).schemaVersion, BROWSER_SCHEMA_VERSION);
  const migratedWorkspaces = JSON.parse(storage.getItem("francis-os-workspaces-v2"));
  assert.equal(migratedWorkspaces.version, 2);
  assert.equal(migratedWorkspaces.activeWorkspaceId, "personal");
  assert.deepEqual(Object.keys(migratedWorkspaces.workspaces).sort(), ["focus", "personal", "work"]);
  assert.equal(migratedWorkspaces.workspaces.work.defaultApplication, "calendar");
  assert.equal(migratedWorkspaces.workspaces.personal.defaultApplication, "interest-hub");
  assert.equal(migratedWorkspaces.workspaces.focus.defaultApplication, "focus-timer");
  assert.equal(migratedWorkspaces.workspaces.focus.dock.minimal, true);
  assert.equal(migratedWorkspaces.workspaces.focus.notifications.noncritical, false);
  assert.ok(migratedWorkspaces.workspaces.work.applications.includes("integration-status"));
  assert.ok(migratedWorkspaces.workspaces.personal.applications.includes("youtube"));
  assert.ok(migratedWorkspaces.workspaces.focus.applications.includes("objective"));

  const v43Scene = JSON.stringify({
    version: 2,
    active: "focus",
    profiles: {
      work: { links: [{ label: "Research", url: "https://example.com/research", icon: "R" }], hue: 11 },
      personal: { youtubeId: "jfKfPfyJRdk", vaultView: "photos" },
      focus: { themeMode: "night", hue: 222, layout: "focus" },
    },
  });
  const v43Storage = browserStorageFixture({
    "dashboard-scenes-v1": v43Scene,
    "francis-os-system-state-v1": JSON.stringify({
      format: "francis-os-system-state",
      schemaVersion: 1,
      registryVersion: 1,
      appVersion: 43,
      migrations: [],
    }),
  });
  const v43Window = { localStorage: v43Storage };
  vm.runInNewContext(browserSource, { window: v43Window, Date, JSON, Object, Error, Number, Array });
  const v44Boot = v43Window.FrancisSystemFoundation.boot({ storage: v43Storage });
  const v44Workspaces = JSON.parse(v43Storage.getItem("francis-os-workspaces-v2"));
  assert.equal(v44Boot.state.schemaVersion, 2);
  assert.equal(v44Workspaces.activeWorkspaceId, "focus");
  assert.equal(v44Workspaces.workspaces.work.quickLinks[0].label, "Research");
  assert.equal(v44Workspaces.workspaces.focus.appearance.themeMode, "night");
  assert.equal(v44Workspaces.workspaces.focus.appearance.hue, 222);
  assert.equal(v43Storage.getItem("dashboard-scenes-v1"), v43Scene);

  const futureStorage = browserStorageFixture({
    "dashboard-scenes-v1": preservedScene,
    "francis-os-system-state-v1": JSON.stringify({ schemaVersion: BROWSER_SCHEMA_VERSION + 1 }),
  });
  const futureWindow = { localStorage: futureStorage };
  vm.runInNewContext(browserSource, { window: futureWindow, Date, JSON, Object, Error, Number, Array });
  assert.throws(() => futureWindow.FrancisSystemFoundation.boot({ storage: futureStorage }), /newer than/);
  assert.equal(futureStorage.getItem("dashboard-scenes-v1"), preservedScene);

  const rollbackStorage = browserStorageFixture({ "dashboard-scenes-v1": preservedScene });
  const rollbackWindow = { localStorage: rollbackStorage };
  vm.runInNewContext(browserSource, { window: rollbackWindow, Date, JSON, Object, Error, Number, Array });
  assert.throws(() => rollbackWindow.FrancisSystemFoundation.migrate(rollbackStorage, {
    currentVersion: 1,
    migrationPlan: [{
      id: "intentional-test-failure",
      from: 0,
      to: 1,
      up(activeStorage) {
        activeStorage.setItem("dashboard-scenes-v1", "corrupted");
        throw new Error("Intentional migration failure");
      },
    }],
  }), /Intentional migration failure/);
  assert.equal(rollbackStorage.getItem("dashboard-scenes-v1"), preservedScene);
  assert.equal(rollbackStorage.getItem("francis-os-system-state-v1"), null);
}

async function run() {
  validateFoundationPrimitives();
  await new Promise((resolve) => mockNews.listen(mockPort, "127.0.0.1", resolve));
  fs.writeFileSync(settingsPath, JSON.stringify({
    version: 1,
    name: "Francis",
    location: {
      label: "Austin, Texas",
      latitude: 30.2986,
      longitude: -97.7028,
      timezone: "America/Chicago",
    },
    storagePath: vaultPath,
    notesExportPath: path.join(root, "Notebook Exports"),
    defaults: { themeMode: "auto", vaultView: "recent", youtubeId: "jfKfPfyJRdk" },
  }));
  fs.writeFileSync(spotifyPath, JSON.stringify({
    clientId: "fixture-client-id-1234",
    refreshToken: "fixture-refresh-token",
    accessToken: "fixture-access-token",
    expiresAt: Date.now() + 3_600_000,
  }));
  fs.writeFileSync(calendarPath, JSON.stringify({
    secretIcalUrl: "https://calendar.google.com/calendar/ical/fixture/private-fixture/basic.ics",
    calendarName: "Fixture Calendar",
    agendaCache: { connected: true, calendarName: "Fixture Calendar", events: [], fetchedAt: new Date().toISOString() },
  }));
  let dashboard = launchDashboard();
  try {
    await waitForDashboard();
    let response = await fetch("http://127.0.0.1:4175/api/version");
    let value = await response.json();
    assert.equal(value.version, APP_VERSION);
    assert.equal(value.registryVersion, REGISTRY_VERSION);
    assert.equal(value.schemas.settings, SETTINGS_SCHEMA_VERSION);
    assert.equal(value.schemas.browser, BROWSER_SCHEMA_VERSION);

    response = await fetch("http://127.0.0.1:4175/system-foundation-browser.js");
    const browserFoundation = await response.text();
    assert.equal(response.status, 200);
    assert.match(response.headers.get("content-type"), /javascript/);
    assert.match(browserFoundation, /FrancisSystemFoundation/);

    response = await fetch("http://127.0.0.1:4175/api/system/registry?workspace=personal");
    value = await response.json();
    assert.equal(response.status, 200);
    assert.equal(value.appVersion, APP_VERSION);
    assert.equal(value.workspaces.find((workspace) => workspace.workspaceId === "personal").active, true);
    assert.deepEqual(
      value.workspaces.map((workspace) => workspace.workspaceId).sort(),
      ["focus", "personal", "work"],
    );
    for (const application of value.applications) {
      for (const field of [
        "applicationId",
        "name",
        "icon",
        "supportedWorkspaces",
        "sizes",
        "requiredIntegrations",
        "health",
        "permissions",
        "savedState",
      ]) {
        assert.notEqual(application[field], undefined, `${application.applicationId} is missing ${field}`);
      }
    }
    for (const requiredApplication of [
      "calendar",
      "spotify",
      "youtube",
      "files",
      "notebook",
      "quick-launch",
      "interest-hub",
      "headlines",
      "countdowns",
      "settings",
      "dock",
      "integration-status",
      "focus-timer",
      "objective",
    ]) {
      assert.ok(value.applications.some((application) => application.applicationId === requiredApplication));
    }
    assert.ok(value.integrations.length >= 9);
    assert.ok(value.storageLocations.length >= 4);
    assert.ok(value.settings.length >= 9);
    assert.ok(value.notifications.length >= 4);
    assert.ok(value.userData.length >= 10);

    response = await fetch("http://127.0.0.1:4175/api/system/health?workspace=personal");
    value = await response.json();
    assert.equal(response.status, 200);
    assert.equal(value.appVersion, APP_VERSION);
    assert.ok(value.applications.calendar);
    assert.ok(value.integrations["google-calendar"]);
    assert.ok(value.storageLocations.some((location) => location.storageLocationId === "personal-vault"));

    response = await fetch("http://127.0.0.1:4175/api/settings");
    value = await response.json();
    assert.equal(value.schemaVersion, SETTINGS_SCHEMA_VERSION);
    assert.equal(value.name, "Francis");
    const migratedDiskSettings = JSON.parse(fs.readFileSync(settingsPath, "utf8"));
    assert.equal(migratedDiskSettings.schemaVersion, SETTINGS_SCHEMA_VERSION);
    assert.equal(migratedDiskSettings.name, "Francis");

    const migratedVaultRoot = path.join(root, "migrated-vault");
    response = await fetch("http://127.0.0.1:4175/api/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: "Francis", storagePath: migratedVaultRoot }),
    });
    value = await response.json();
    assert.equal(value.notesExportPath, path.join(migratedVaultRoot, "Notebook Exports"));

    const exportRoot = path.join(root, "notebook-exports");
    response = await fetch("http://127.0.0.1:4175/api/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: "Francis",
        storagePath: path.join(root, "vault"),
        notesExportPath: exportRoot,
      }),
    });
    value = await response.json();
    assert.equal(response.status, 200);
    assert.equal(value.notesExportPath, exportRoot);

    response = await fetch("http://127.0.0.1:4175/api/notebook/export", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        saveToFolder: true,
        tabs: [{ id: "calls", label: "Call Notes", content: "A verified export." }],
      }),
    });
    value = await response.json();
    assert.equal(response.status, 200);
    assert.equal(value.saved, true);
    assert.equal(path.dirname(value.path), exportRoot);
    assert.equal(path.extname(value.path), ".docx");
    assert.equal(fs.readFileSync(value.path).subarray(0, 2).toString("ascii"), "PK");

    if (process.platform !== "win32") {
      response = await fetch("http://127.0.0.1:4175/api/folder-picker", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ purpose: "storage", initialPath: exportRoot }),
      });
      value = await response.json();
      assert.equal(response.status, 503);
      assert.match(value.error, /Windows dashboard/);
      response = await fetch("http://127.0.0.1:4175/api/application/open?application=spotify", {
        method: "POST",
      });
      value = await response.json();
      assert.equal(response.status, 503);
      assert.match(value.error, /Windows package/);
    }

    response = await fetch("http://127.0.0.1:4175/api/interests?channel=technology&q=AI");
    value = await response.json();
    assert.equal(response.status, 200);
    assert.equal(value.channel, "technology");
    assert.equal(value.items.length, 5);
    assert.equal(value.items[0].title, "Premium dashboard technology story");
    assert.match(value.items[0].image, /^https:\/\//);

    response = await fetch("http://127.0.0.1:4175/api/interests?channel=gaming&q=Nintendo");
    value = await response.json();
    assert.equal(value.channel, "gaming");
    assert.equal(value.items.length, 5);

    response = await fetch("http://127.0.0.1:4175/api/interests?channel=golf&q=PGA");
    value = await response.json();
    assert.equal(value.channel, "golf");
    assert.equal(value.items.length, 5);

    response = await fetch("http://127.0.0.1:4175/api/vault");
    value = await response.json();
    assert.ok(!value.categories.some((category) => category.id === "private"));
    const privateToken = "test_private_session_token_1234567890";
    response = await fetch("http://127.0.0.1:4175/api/private-session", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token: privateToken }),
    });
    assert.equal(response.status, 200);
    response = await fetch(`http://127.0.0.1:4175/api/vault?privateToken=${privateToken}`);
    value = await response.json();
    assert.ok(value.categories.some((category) => category.id === "private"));
    response = await fetch(`http://127.0.0.1:4175/api/vault/upload?category=private&name=fixture.png&privateToken=${privateToken}`, {
      method: "POST",
      headers: { "Content-Type": "image/png" },
      body: Buffer.from("private-fixture"),
    });
    assert.equal(response.status, 201);
    response = await fetch(`http://127.0.0.1:4175/api/vault?privateToken=${privateToken}`);
    value = await response.json();
    assert.ok(value.files.some((file) => file.category === "private" && file.name === "fixture.png"));

    response = await fetch("http://127.0.0.1:4175/api/bluesky/connect", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ identifier: "francis.bsky.social", appPassword: "app-pass-test" }),
    });
    assert.equal(response.status, 401);
    response = await fetch("http://127.0.0.1:4175/api/bluesky/connect", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ privateToken, identifier: "francis.bsky.social", appPassword: "app-pass-test" }),
    });
    assert.equal(response.status, 200);
    const connection = await response.json();
    assert.equal(connection.session.handle, "francis.bsky.social");

    response = await fetch("http://127.0.0.1:4175/api/bluesky/feed", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        privateToken,
        session: connection.session,
        sources: [{ id: "search-1", type: "search", label: "Test", value: "technology" }],
        includeAdult: false,
      }),
    });
    assert.equal(response.status, 200);
    value = await response.json();
    assert.equal(value.posts.length, 1);
    assert.equal(value.posts[0].media.type, "image");
    assert.equal(value.posts[0].adult, false);

    response = await fetch("http://127.0.0.1:4175/api/bluesky/feed", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        privateToken,
        session: connection.session,
        sources: [{ id: "search-1", type: "search", label: "Test", value: "technology" }],
        includeAdult: true,
      }),
    });
    value = await response.json();
    assert.equal(value.posts.length, 2);
    assert.ok(value.posts.some((post) => post.adult));

    const dashboardHtml = fs.readFileSync(path.join(__dirname, "dashboard.html"), "utf8");
    assert.match(dashboardHtml, /system-foundation-browser\.js/);
    assert.match(dashboardHtml, /FrancisSystemFoundation\.boot/);
    assert.match(dashboardHtml, /api\/system\/registry/);
    assert.match(dashboardHtml, /francis-os-system-state-v1/);
    assert.match(dashboardHtml, /francis-os-workspaces-v2/);
    assert.match(dashboardHtml, /francis-os-focus-timer-v1/);
    assert.match(dashboardHtml, /id="workspaceDock"/);
    assert.doesNotMatch(dashboardHtml, /id="workspaceDockIdentity"/);
    assert.match(dashboardHtml, /aria-label="Application Dock"/);
    assert.match(dashboardHtml, /api\/application\/open\?application=spotify/);
    assert.match(dashboardHtml, /https:\/\/www\.youtube\.com\/watch\?v=/);
    assert.match(dashboardHtml, /https:\/\/calendar\.google\.com\//);
    assert.match(dashboardHtml, /api\/vault\/open-folder/);
    assert.match(dashboardHtml, /id="workspaceApplicationSettings"/);
    assert.match(dashboardHtml, /id="workspaceDockSettings"/);
    assert.match(dashboardHtml, /id="workspaceDefaultApplication"/);
    assert.match(dashboardHtml, /id="focusTimerPanel"/);
    assert.match(dashboardHtml, /id="focusObjectivePanel"/);
    assert.match(dashboardHtml, /id="integrationStatusPanel"/);
    assert.match(dashboardHtml, /position:\{\s*scrollY:/);
    assert.match(dashboardHtml, /openWorkspaceApplication\(profile\.defaultApplication/);
    assert.match(dashboardHtml, /Interest Hub/);
    assert.match(dashboardHtml, /data-interest-tab="technology"/);
    assert.match(dashboardHtml, /data-interest-tab="gaming"/);
    assert.match(dashboardHtml, /data-interest-tab="golf"/);
    assert.doesNotMatch(dashboardHtml, /data-interest-tab="private"/);
    assert.match(dashboardHtml, /interestCache=\{technology:null,gaming:null,golf:null\}/);
    assert.match(dashboardHtml, /interest-story-media/);
    assert.match(dashboardHtml, /PBKDF2/);
    assert.match(dashboardHtml, /AES-GCM/);
    assert.match(dashboardHtml, /Show properly labeled adult content/);
    assert.match(dashboardHtml, /Private Vault/);
    assert.doesNotMatch(dashboardHtml, /Reddit Interests/);
    assert.match(dashboardHtml, /id="settingsStorageBrowse"/);
    assert.match(dashboardHtml, /id="settingsNotesExportBrowse"/);
    assert.match(dashboardHtml, /notesExportPath/);
    assert.match(dashboardHtml, /saveToFolder:true/);
    assert.match(dashboardHtml, /storage-map\+\.storage-path-block/);
    assert.doesNotMatch(dashboardHtml, /storage-path-block\+\.storage-path-block/);
    assert.match(dashboardHtml, /right\.insertBefore\(quick,countdowns\)/);
    assert.match(dashboardHtml, /left\.appendChild\(quick\)/);
    assert.match(dashboardHtml, /left\.insertBefore\(quick,interests\)/);
    assert.match(dashboardHtml, /sceneLayoutQuery\.addEventListener/);
    assert.match(dashboardHtml, /body\.scene-personal \.quick-panel \.quick-grid/);
    const pickerScript = fs.readFileSync(path.join(__dirname, "folder-picker.ps1"), "utf8");
    assert.match(pickerScript, /\$owner\.TopMost = \$true/);
    assert.match(pickerScript, /\$dialog\.ShowDialog\(\$owner\)/);
    const persistedFiles = fs.readdirSync(root, { recursive: true })
      .filter((name) => fs.statSync(path.join(root, name)).isFile());
    assert.ok(!persistedFiles.some((name) => fs.readFileSync(path.join(root, name), "utf8").includes("app-pass-test")));

    response = await fetch("http://127.0.0.1:4175/api/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...migratedDiskSettings,
        name: "Francis Restart Check",
        storagePath: vaultPath,
        notesExportPath: exportRoot,
      }),
    });
    assert.equal(response.status, 200);
    await stopDashboard(dashboard);
    dashboard = launchDashboard();
    await waitForDashboard();
    response = await fetch("http://127.0.0.1:4175/api/settings");
    value = await response.json();
    assert.equal(value.name, "Francis Restart Check");
    assert.equal(value.storagePath, vaultPath);
    assert.equal(value.notesExportPath, exportRoot);
    assert.equal(JSON.parse(fs.readFileSync(spotifyPath, "utf8")).refreshToken, "fixture-refresh-token");
    assert.equal(JSON.parse(fs.readFileSync(calendarPath, "utf8")).calendarName, "Fixture Calendar");
    response = await fetch("http://127.0.0.1:4175/api/private-session", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token: privateToken }),
    });
    assert.equal(response.status, 200);
    response = await fetch(`http://127.0.0.1:4175/api/vault?privateToken=${privateToken}`);
    value = await response.json();
    assert.ok(value.files.some((file) => file.category === "private" && file.name === "fixture.png"));

    console.log("v44 Workspaces, migration, registry, restart persistence, V42 layout, storage, export, and Interest Hub tests passed.");
  } finally {
    await stopDashboard(dashboard);
    await new Promise((resolve) => mockNews.close(resolve));
    fs.rmSync(root, { recursive: true, force: true });
  }
}

run().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
