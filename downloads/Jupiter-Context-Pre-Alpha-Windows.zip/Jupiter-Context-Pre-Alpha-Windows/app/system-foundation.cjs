"use strict";

const fs = require("node:fs");
const path = require("node:path");

const APP_VERSION = 45;
const REGISTRY_VERSION = 3;
const SETTINGS_SCHEMA_VERSION = 1;
const BROWSER_SCHEMA_VERSION = 3;

const size = (columns, rows) => Object.freeze({ columns, rows });
const permission = (id, access, purpose) => Object.freeze({ id, access, purpose });
const savedState = (scope, storage, keys = []) => Object.freeze({
  scope,
  storage,
  keys: Object.freeze([...keys]),
});

const APPLICATIONS = Object.freeze([
  {
    applicationId: "weather",
    name: "Weather",
    icon: "☀",
    supportedWorkspaces: ["work", "personal", "focus"],
    sizes: { compact: size(6, 2), expanded: size(8, 4) },
    requiredIntegrations: ["open-meteo"],
    permissions: [permission("location", "read", "Load local weather, sunrise, sunset, and timezone.")],
    savedState: savedState("profile", "dashboard-settings", ["location"]),
  },
  {
    applicationId: "calendar",
    name: "Calendar",
    icon: "31",
    supportedWorkspaces: ["work"],
    sizes: { compact: size(6, 3), expanded: size(8, 5) },
    requiredIntegrations: ["google-calendar"],
    permissions: [permission("calendar", "read", "Read the configured secret iCal agenda.")],
    savedState: savedState("device", "local-app-data", ["google-calendar-connection.json"]),
  },
  {
    applicationId: "spotify",
    name: "Spotify",
    icon: "♫",
    supportedWorkspaces: ["work", "personal", "focus"],
    sizes: { compact: size(4, 2), expanded: size(6, 3) },
    requiredIntegrations: ["spotify"],
    permissions: [
      permission("playback", "read", "Read the active Spotify player."),
      permission("playback", "control", "Play, pause, skip, and return to the previous track."),
    ],
    savedState: savedState("device", "local-app-data", ["spotify-connection.json"]),
  },
  {
    applicationId: "youtube",
    name: "YouTube",
    icon: "▶",
    supportedWorkspaces: ["personal"],
    sizes: { compact: size(6, 3), expanded: size(8, 5) },
    requiredIntegrations: ["youtube"],
    permissions: [permission("media", "embed", "Load the selected privacy-enhanced YouTube video.")],
    savedState: savedState("workspace", "browser-local-storage", ["morning-youtube-id", "francis-os-workspaces-v2"]),
  },
  {
    applicationId: "files",
    name: "Files",
    icon: "◇",
    supportedWorkspaces: ["work", "personal", "focus"],
    sizes: { compact: size(4, 3), expanded: size(8, 6) },
    requiredIntegrations: ["local-filesystem"],
    permissions: [
      permission("vault", "read", "Index and preview files inside configured Vault categories."),
      permission("vault", "write", "Upload files to configured Vault categories."),
    ],
    savedState: savedState("user", "personal-vault", ["Family Photos", "Family Videos", "Personal Projects", "Private Vault"]),
  },
  {
    applicationId: "notebook",
    name: "Notebook",
    icon: "✎",
    supportedWorkspaces: ["work", "personal", "focus"],
    sizes: { compact: size(5, 4), expanded: size(10, 7) },
    requiredIntegrations: ["browser-storage", "local-filesystem"],
    permissions: [
      permission("notes", "read-write", "Save notebook tabs in this browser."),
      permission("exports", "write", "Create Word exports in the configured export folder."),
    ],
    savedState: savedState("browser", "browser-local-storage", ["dashboard-notebook-v1", "dashboard-call-notes"]),
  },
  {
    applicationId: "quick-launch",
    name: "Quick Launch",
    icon: "↗",
    supportedWorkspaces: ["work", "personal", "focus"],
    sizes: { compact: size(4, 2), expanded: size(6, 3) },
    requiredIntegrations: ["browser-storage"],
    permissions: [permission("links", "read-write", "Remember six workspace shortcuts.")],
    savedState: savedState("workspace", "browser-local-storage", ["morning-links", "francis-os-workspaces-v2"]),
  },
  {
    applicationId: "interest-hub",
    name: "Interest Hub",
    icon: "✦",
    supportedWorkspaces: ["personal"],
    sizes: { compact: size(6, 4), expanded: size(8, 7) },
    requiredIntegrations: ["google-news"],
    permissions: [permission("news", "read", "Load public Technology, Gaming, and Golf stories.")],
    savedState: savedState("browser", "browser-local-storage", ["dashboard-interest-hub-v1"]),
  },
  {
    applicationId: "headlines",
    name: "Headlines",
    icon: "≡",
    supportedWorkspaces: ["work", "personal"],
    sizes: { compact: size(4, 4), expanded: size(6, 6) },
    requiredIntegrations: ["google-news"],
    permissions: [permission("news", "read", "Load one headline for each configured topic.")],
    savedState: savedState("workspace", "dashboard-settings", ["newsTopics", "francis-os-workspaces-v2"]),
  },
  {
    applicationId: "countdowns",
    name: "Countdowns",
    icon: "＋",
    supportedWorkspaces: ["personal"],
    sizes: { compact: size(4, 2), expanded: size(6, 4) },
    requiredIntegrations: ["browser-storage"],
    permissions: [permission("countdowns", "read-write", "Remember named dates in this browser.")],
    savedState: savedState("browser", "browser-local-storage", ["morning-countdowns"]),
  },
  {
    applicationId: "settings",
    name: "Settings",
    icon: "⚙",
    supportedWorkspaces: ["work", "personal", "focus"],
    sizes: { compact: size(6, 5), expanded: size(12, 8) },
    requiredIntegrations: ["local-settings", "browser-storage"],
    permissions: [permission("configuration", "read-write", "Manage Francis OS preferences and defaults.")],
    savedState: savedState("user", "mixed", ["dashboard-settings.json", "browser preferences"]),
  },
  {
    applicationId: "command-center",
    name: "Command Center",
    icon: "✦",
    supportedWorkspaces: ["work", "personal", "focus"],
    sizes: { compact: size(6, 1), expanded: size(8, 5) },
    requiredIntegrations: ["chatgpt"],
    permissions: [permission("commands", "execute", "Run registered local actions or open a ChatGPT request.")],
    savedState: savedState("runtime", "memory", []),
  },
  {
    applicationId: "dock",
    name: "Workspace Dock",
    icon: "▰",
    supportedWorkspaces: ["work", "personal", "focus"],
    sizes: { compact: size(4, 1), expanded: size(8, 1) },
    requiredIntegrations: ["browser-storage"],
    permissions: [permission("applications", "open", "Open applications registered to the active Workspace.")],
    savedState: savedState("workspace", "browser-local-storage", ["francis-os-workspaces-v2"]),
  },
  {
    applicationId: "integration-status",
    name: "Integration Status",
    icon: "●",
    supportedWorkspaces: ["work"],
    sizes: { compact: size(4, 2), expanded: size(6, 3) },
    requiredIntegrations: ["local-settings"],
    permissions: [permission("health", "read", "Read the local system health registry.")],
    savedState: savedState("runtime", "memory", []),
  },
  {
    applicationId: "focus-timer",
    name: "Focus Timer",
    icon: "◎",
    supportedWorkspaces: ["focus"],
    sizes: { compact: size(4, 2), expanded: size(6, 3) },
    requiredIntegrations: ["browser-storage"],
    permissions: [permission("timer", "read-write", "Remember the current focus session on this browser.")],
    savedState: savedState("browser", "browser-local-storage", ["francis-os-focus-timer-v1"]),
  },
  {
    applicationId: "objective",
    name: "Objective",
    icon: "→",
    supportedWorkspaces: ["focus"],
    sizes: { compact: size(4, 1), expanded: size(6, 2) },
    requiredIntegrations: ["browser-storage"],
    permissions: [permission("objective", "read-write", "Remember the active Focus objective.")],
    savedState: savedState("workspace", "browser-local-storage", ["francis-os-workspaces-v2"]),
  },
]);

const APPLICATION_LAUNCH = Object.freeze({
  weather: { mode: "internal", dockable: true },
  calendar: { mode: "web", target: "https://calendar.google.com/", dockable: true },
  spotify: { mode: "desktop-preferred", target: "spotify:", fallback: "https://open.spotify.com/", dockable: true },
  youtube: { mode: "web", target: "https://www.youtube.com/", dockable: true },
  files: { mode: "local-folder", dockable: true },
  notebook: { mode: "internal", dockable: true },
  "quick-launch": { mode: "internal", dockable: true },
  "interest-hub": { mode: "internal", dockable: false },
  headlines: { mode: "internal", dockable: true },
  countdowns: { mode: "internal", dockable: false },
  settings: { mode: "internal", dockable: true },
  "command-center": { mode: "internal", dockable: false },
  dock: { mode: "system", dockable: false },
  "integration-status": { mode: "internal", dockable: true },
  "focus-timer": { mode: "internal", dockable: true },
  objective: { mode: "internal", dockable: true },
});

const WORKSPACES = Object.freeze([
  {
    workspaceId: "work",
    name: "Work",
    icon: "◆",
    layout: "full",
    applications: ["weather", "calendar", "headlines", "quick-launch", "spotify", "files", "integration-status", "notebook", "settings", "command-center", "dock"],
    savedState: savedState("browser", "browser-local-storage", ["francis-os-workspaces-v2"]),
  },
  {
    workspaceId: "personal",
    name: "Personal",
    icon: "⌂",
    layout: "full",
    applications: ["weather", "youtube", "interest-hub", "countdowns", "files", "headlines", "spotify", "quick-launch", "notebook", "settings", "command-center", "dock"],
    savedState: savedState("browser", "browser-local-storage", ["francis-os-workspaces-v2"]),
  },
  {
    workspaceId: "focus",
    name: "Focus",
    icon: "◎",
    layout: "focus",
    applications: ["weather", "spotify", "focus-timer", "objective", "quick-launch", "files", "notebook", "settings", "command-center", "dock"],
    savedState: savedState("browser", "browser-local-storage", ["francis-os-workspaces-v2"]),
  },
]);

const INTEGRATIONS = Object.freeze([
  { integrationId: "local-settings", name: "Local Settings", type: "local", permissions: ["read", "write"] },
  { integrationId: "browser-storage", name: "Browser Storage", type: "local", permissions: ["read", "write"] },
  { integrationId: "local-filesystem", name: "Windows Filesystem", type: "local", permissions: ["read", "write", "open"] },
  { integrationId: "open-meteo", name: "Open-Meteo", type: "public-api", permissions: ["read"] },
  { integrationId: "google-news", name: "Google News", type: "public-feed", permissions: ["read"] },
  { integrationId: "google-calendar", name: "Google Calendar", type: "private-feed", permissions: ["read"] },
  { integrationId: "spotify", name: "Spotify", type: "oauth-pkce", permissions: ["playback-read", "playback-control"] },
  { integrationId: "youtube", name: "YouTube", type: "embedded-media", permissions: ["embed"] },
  { integrationId: "chatgpt", name: "ChatGPT", type: "external-application", permissions: ["open"] },
]);

const SETTINGS = Object.freeze([
  { settingsId: "identity", name: "Identity", owns: ["name"] },
  { settingsId: "workspaces", name: "Workspaces", owns: ["francis-os-workspaces-v2", "dashboard-scenes-v1"] },
  { settingsId: "calendar", name: "Calendar", owns: ["google-calendar-connection.json"] },
  { settingsId: "location", name: "Location", owns: ["location"] },
  { settingsId: "storage", name: "Storage", owns: ["storagePath", "notesExportPath"] },
  { settingsId: "interests", name: "Interest Hub", owns: ["dashboard-interest-hub-v1"] },
  { settingsId: "quick-launch", name: "Quick Launch", owns: ["morning-links", "francis-os-workspaces-v2"] },
  { settingsId: "headlines", name: "Headlines", owns: ["newsTopics", "francis-os-workspaces-v2"] },
  { settingsId: "defaults", name: "Defaults", owns: ["defaults", "francis-os-workspaces-v2"] },
]);

const NOTIFICATIONS = Object.freeze([
  { notificationId: "system-status", name: "System Status", channel: "inline", persistence: "runtime" },
  { notificationId: "workspace-transition", name: "Workspace Transition", channel: "toast", persistence: "runtime" },
  { notificationId: "integration-status", name: "Integration Status", channel: "module", persistence: "runtime" },
  { notificationId: "storage-status", name: "Storage Status", channel: "module", persistence: "runtime" },
]);

const USER_DATA = Object.freeze([
  { userDataId: "profile", owner: "settings", storage: "dashboard-settings", migrationPolicy: "preserve" },
  { userDataId: "workspace-profiles", owner: "workspaces", storage: "francis-os-workspaces-v2", migrationPolicy: "versioned" },
  { userDataId: "legacy-scene-profiles", owner: "compatibility", storage: "dashboard-scenes-v1", migrationPolicy: "preserve-hidden" },
  { userDataId: "quick-launch-links", owner: "quick-launch", storage: "morning-links", migrationPolicy: "preserve" },
  { userDataId: "countdowns", owner: "countdowns", storage: "morning-countdowns", migrationPolicy: "preserve" },
  { userDataId: "notebook", owner: "notebook", storage: "dashboard-notebook-v1", migrationPolicy: "preserve" },
  { userDataId: "media-preferences", owner: "youtube", storage: "morning-youtube-id", migrationPolicy: "preserve" },
  { userDataId: "interest-preferences", owner: "interest-hub", storage: "dashboard-interest-hub-v1", migrationPolicy: "preserve" },
  { userDataId: "focus-session", owner: "focus-timer", storage: "francis-os-focus-timer-v1", migrationPolicy: "preserve" },
  { userDataId: "vault-files", owner: "files", storage: "personal-vault", migrationPolicy: "never-delete" },
  { userDataId: "integration-connections", owner: "integrations", storage: "local-app-data", migrationPolicy: "never-export" },
  { userDataId: "legacy-private-space", owner: "compatibility", storage: "dashboard-private-space-v1", migrationPolicy: "preserve-hidden" },
]);

const clone = (value) => JSON.parse(JSON.stringify(value));

function health(status = "ready", detail = "") {
  return { status, detail, checkedAt: new Date().toISOString() };
}

function migrateVersionedData(rawValue, {
  currentVersion,
  migrations,
  versionKey = "schemaVersion",
} = {}) {
  if (!Number.isInteger(currentVersion) || currentVersion < 0) {
    throw new Error("A non-negative current schema version is required.");
  }
  let value = rawValue && typeof rawValue === "object" ? clone(rawValue) : {};
  const startingVersion = Number.isInteger(Number(value[versionKey]))
    ? Number(value[versionKey])
    : 0;
  if (startingVersion > currentVersion) {
    throw new Error(`Data schema ${startingVersion} is newer than supported schema ${currentVersion}.`);
  }
  let version = startingVersion;
  const applied = [];
  while (version < currentVersion) {
    const migration = migrations.find((candidate) => candidate.from === version);
    if (!migration || migration.to !== version + 1 || typeof migration.up !== "function") {
      throw new Error(`Missing migration from schema ${version} to ${version + 1}.`);
    }
    value = migration.up(clone(value));
    version = migration.to;
    value[versionKey] = version;
    applied.push({ from: migration.from, to: migration.to, id: migration.id });
  }
  return {
    value,
    changed: applied.length > 0,
    fromVersion: startingVersion,
    toVersion: version,
    applied,
  };
}

const SETTINGS_MIGRATIONS = Object.freeze([
  {
    id: "v43-foundation-envelope",
    from: 0,
    to: 1,
    up(value) {
      return {
        ...value,
        schemaVersion: 1,
        systemMeta: {
          ...(value.systemMeta && typeof value.systemMeta === "object" ? value.systemMeta : {}),
          registryVersion: REGISTRY_VERSION,
          migratedFromSchema: 0,
          migratedByAppVersion: APP_VERSION,
        },
      };
    },
  },
]);

function migrateDashboardSettings(rawValue) {
  return migrateVersionedData(rawValue, {
    currentVersion: SETTINGS_SCHEMA_VERSION,
    migrations: SETTINGS_MIGRATIONS,
  });
}

function atomicWriteJson(filename, value) {
  fs.mkdirSync(path.dirname(filename), { recursive: true });
  const temporary = `${filename}.${process.pid}.${Date.now()}.tmp`;
  try {
    fs.writeFileSync(temporary, JSON.stringify(value, null, 2), "utf8");
    fs.renameSync(temporary, filename);
  } catch (error) {
    try {
      if (fs.existsSync(temporary)) fs.unlinkSync(temporary);
    } catch {}
    throw error;
  }
}

function applicationHealth(definition, applicationHealthMap, integrationHealthMap) {
  const explicit = applicationHealthMap[definition.applicationId];
  if (explicit) return explicit;
  const dependencies = definition.requiredIntegrations.map((id) => integrationHealthMap[id]).filter(Boolean);
  if (dependencies.some((item) => item.status === "unavailable" || item.status === "error")) {
    return health("degraded", "A required integration is unavailable.");
  }
  if (dependencies.some((item) => item.status === "not_configured")) {
    return health("not_configured", "An optional connection has not been configured.");
  }
  return health("ready", "Application definition loaded.");
}

function buildRegistry({
  applicationHealth: applicationHealthMap = {},
  integrationHealth: integrationHealthMap = {},
  storageLocations = [],
  activeWorkspace = "work",
} = {}) {
  const integrations = INTEGRATIONS.map((definition) => ({
    ...clone(definition),
    health: integrationHealthMap[definition.integrationId] || health("ready", "Integration definition loaded."),
  }));
  const integrationMap = Object.fromEntries(integrations.map((item) => [item.integrationId, item.health]));
  const applications = APPLICATIONS.map((definition) => ({
    ...clone(definition),
    launch: clone(APPLICATION_LAUNCH[definition.applicationId] || { mode: "internal", dockable: true }),
    health: applicationHealth(definition, applicationHealthMap, integrationMap),
  }));
  const applicationMap = Object.fromEntries(applications.map((item) => [item.applicationId, item.health]));
  const workspaces = WORKSPACES.map((definition) => {
    const states = definition.applications.map((id) => applicationMap[id]).filter(Boolean);
    const degraded = states.some((item) => ["degraded", "unavailable", "error"].includes(item.status));
    return {
      ...clone(definition),
      active: definition.workspaceId === activeWorkspace,
      health: health(degraded ? "degraded" : "ready", degraded ? "One or more applications need attention." : "Workspace definition loaded."),
    };
  });
  return {
    appVersion: APP_VERSION,
    registryVersion: REGISTRY_VERSION,
    schemas: {
      settings: SETTINGS_SCHEMA_VERSION,
      browser: BROWSER_SCHEMA_VERSION,
    },
    generatedAt: new Date().toISOString(),
    applications,
    workspaces,
    integrations,
    storageLocations: clone(storageLocations),
    settings: clone(SETTINGS),
    notifications: clone(NOTIFICATIONS),
    userData: clone(USER_DATA),
  };
}

function validateRegistry(registry) {
  const applicationIds = new Set();
  for (const application of registry.applications || []) {
    const required = [
      "applicationId",
      "name",
      "icon",
      "supportedWorkspaces",
      "sizes",
      "requiredIntegrations",
      "launch",
      "health",
      "permissions",
      "savedState",
    ];
    const missing = required.filter((field) => application[field] === undefined);
    if (missing.length) throw new Error(`${application.applicationId || "Unknown application"} is missing ${missing.join(", ")}.`);
    if (applicationIds.has(application.applicationId)) throw new Error(`Duplicate application ID: ${application.applicationId}.`);
    applicationIds.add(application.applicationId);
  }
  for (const workspace of registry.workspaces || []) {
    for (const applicationId of workspace.applications || []) {
      if (!applicationIds.has(applicationId)) {
        throw new Error(`${workspace.workspaceId} references unknown application ${applicationId}.`);
      }
    }
  }
  return true;
}

module.exports = {
  APP_VERSION,
  REGISTRY_VERSION,
  SETTINGS_SCHEMA_VERSION,
  BROWSER_SCHEMA_VERSION,
  APPLICATIONS,
  APPLICATION_LAUNCH,
  WORKSPACES,
  INTEGRATIONS,
  SETTINGS,
  NOTIFICATIONS,
  USER_DATA,
  health,
  migrateVersionedData,
  migrateDashboardSettings,
  atomicWriteJson,
  buildRegistry,
  validateRegistry,
};
