(function initializeFrancisSystemFoundation(global) {
  "use strict";

  const APP_VERSION = 45;
  const REGISTRY_VERSION = 3;
  const BROWSER_SCHEMA_VERSION = 3;
  const STATE_KEY = "francis-os-system-state-v1";
  const WORKSPACE_KEY = "francis-os-workspaces-v2";
  const MANAGED_KEYS = Object.freeze([
    "morning-links",
    "morning-countdowns",
    "dashboard-theme-mode",
    "morning-background-hue",
    "morning-youtube-id",
    "dashboard-vault-view",
    "dashboard-notebook-v1",
    "dashboard-call-notes",
    "dashboard-scenes-v1",
    "dashboard-interest-hub-v1",
    "dashboard-reddit-v1",
    "dashboard-private-space-v1",
    "francis-os-workspaces-v2",
    "francis-os-focus-timer-v1",
  ]);

  const clone = (value) => JSON.parse(JSON.stringify(value));

  function readState(storage) {
    try {
      const value = JSON.parse(storage.getItem(STATE_KEY) || "null");
      return value && typeof value === "object" ? value : {};
    } catch {
      return {};
    }
  }

  function snapshot(storage) {
    const values = {};
    [...MANAGED_KEYS, STATE_KEY].forEach((key) => {
      const value = storage.getItem(key);
      if (value !== null) values[key] = value;
    });
    return values;
  }

  function restore(storage, values) {
    [...MANAGED_KEYS, STATE_KEY].forEach((key) => {
      if (Object.prototype.hasOwnProperty.call(values, key)) storage.setItem(key, values[key]);
      else storage.removeItem(key);
    });
  }

  const migrations = Object.freeze([
    {
      id: "v43-register-existing-user-data",
      from: 0,
      to: 1,
      up(storage) {
        // V42 data already uses durable keys. V43 registers those keys without
        // rewriting their contents, so the first migration is intentionally lossless.
        return storage;
      },
    },
    {
      id: "v44-scenes-to-workspaces",
      from: 1,
      to: 2,
      up(storage) {
        if (storage.getItem(WORKSPACE_KEY)) return storage;
        let legacy = {};
        try {
          legacy = JSON.parse(storage.getItem("dashboard-scenes-v1") || "{}");
        } catch {}
        const legacyProfiles = legacy.profiles && typeof legacy.profiles === "object"
          ? legacy.profiles
          : {};
        const applicationDefaults = {
          work: ["weather", "calendar", "headlines", "quick-launch", "spotify", "files", "integration-status"],
          personal: ["weather", "youtube", "interest-hub", "countdowns", "files", "headlines", "spotify", "quick-launch"],
          focus: ["weather", "spotify", "focus-timer", "objective", "quick-launch"],
        };
        const dockDefaults = {
          work: ["calendar", "headlines", "quick-launch", "spotify", "files", "notebook"],
          personal: ["youtube", "interest-hub", "countdowns", "files", "spotify", "notebook"],
          focus: ["focus-timer", "spotify", "objective", "quick-launch"],
        };
        const defaultApplications = {
          work: "calendar",
          personal: "interest-hub",
          focus: "focus-timer",
        };
        const workspaces = {};
        ["work", "personal", "focus"].forEach((id) => {
          const profile = legacyProfiles[id] && typeof legacyProfiles[id] === "object"
            ? legacyProfiles[id]
            : {};
          workspaces[id] = {
            workspaceId: id,
            applications: applicationDefaults[id],
            layout: profile.layout || (id === "focus" ? "focus" : "full"),
            dock: {
              applications: dockDefaults[id],
              minimal: id === "focus",
            },
            appearance: {
              themeMode: profile.themeMode || (id === "focus" ? "day" : "auto"),
              hue: Number.isFinite(Number(profile.hue)) ? Number(profile.hue) : (id === "personal" ? 18 : id === "focus" ? 190 : 0),
            },
            newsTopics: Array.isArray(profile.newsTopics) ? profile.newsTopics : [],
            quickLinks: Array.isArray(profile.links) ? profile.links : [],
            defaultApplication: defaultApplications[id],
            notifications: {
              noncritical: id !== "focus",
              integrations: id === "work",
              workspaceTransitions: id !== "focus",
            },
            position: {
              scrollY: 0,
              modules: {},
            },
            youtubeId: profile.youtubeId || "",
            vaultView: profile.vaultView || (id === "personal" ? "photos" : id === "focus" ? "projects" : "recent"),
            objective: "",
          };
        });
        const activeWorkspaceId = ["work", "personal", "focus"].includes(legacy.active)
          ? legacy.active
          : "work";
        storage.setItem(WORKSPACE_KEY, JSON.stringify({
          version: 2,
          activeWorkspaceId,
          workspaces,
          migratedFrom: storage.getItem("dashboard-scenes-v1") ? "dashboard-scenes-v1" : "fresh-v44",
        }));
        return storage;
      },
    },
    {
      id: "v45-personal-dock-launchers",
      from: 2,
      to: 3,
      up(storage) {
        let state = {};
        try {
          state = JSON.parse(storage.getItem(WORKSPACE_KEY) || "{}");
        } catch {}
        const personal = state.workspaces?.personal;
        if (!personal || typeof personal !== "object") return storage;
        const existing = Array.isArray(personal.dock?.applications)
          ? personal.dock.applications
          : [];
        const applications = existing.filter((id) => !["interest-hub", "countdowns"].includes(id));
        ["youtube", "files", "spotify", "notebook"].forEach((id) => {
          if (!applications.includes(id)) applications.push(id);
        });
        personal.dock = {
          ...(personal.dock && typeof personal.dock === "object" ? personal.dock : {}),
          applications,
          minimal: false,
        };
        state.version = 3;
        state.updatedAt = new Date().toISOString();
        storage.setItem(WORKSPACE_KEY, JSON.stringify(state));
        return storage;
      },
    },
  ]);

  function migrate(storage, {
    currentVersion = BROWSER_SCHEMA_VERSION,
    migrationPlan = migrations,
  } = {}) {
    const before = snapshot(storage);
    const existing = readState(storage);
    const fromVersion = Number.isInteger(Number(existing.schemaVersion))
      ? Number(existing.schemaVersion)
      : 0;
    if (fromVersion > currentVersion) {
      throw new Error(`Browser data schema ${fromVersion} is newer than this Francis OS build supports.`);
    }
    let version = fromVersion;
    const applied = [];
    try {
      while (version < currentVersion) {
        const migration = migrationPlan.find((candidate) => candidate.from === version);
        if (!migration || migration.to !== version + 1) {
          throw new Error(`Missing browser migration from schema ${version} to ${version + 1}.`);
        }
        migration.up(storage);
        version = migration.to;
        applied.push({
          id: migration.id,
          from: migration.from,
          to: migration.to,
          appliedAt: new Date().toISOString(),
        });
      }
      const next = {
        format: "francis-os-system-state",
        schemaVersion: version,
        registryVersion: REGISTRY_VERSION,
        appVersion: APP_VERSION,
        lastBootAt: new Date().toISOString(),
        migrations: [...(Array.isArray(existing.migrations) ? existing.migrations : []), ...applied].slice(-50),
        managedKeys: [...MANAGED_KEYS],
      };
      storage.setItem(STATE_KEY, JSON.stringify(next));
      return clone(next);
    } catch (error) {
      restore(storage, before);
      throw error;
    }
  }

  function boot({ storage = global.localStorage } = {}) {
    const state = migrate(storage);
    const runtime = {
      appVersion: APP_VERSION,
      registryVersion: REGISTRY_VERSION,
      browserSchemaVersion: BROWSER_SCHEMA_VERSION,
      state,
      registry: null,
      health: { status: "booting", detail: "Loading system registry." },
    };
    global.FrancisOS = runtime;
    return runtime;
  }

  function attachRegistry(registry) {
    if (!global.FrancisOS) boot({});
    global.FrancisOS.registry = registry;
    global.FrancisOS.health = {
      status: "ready",
      detail: `${registry.applications?.length || 0} applications registered.`,
    };
    return global.FrancisOS;
  }

  global.FrancisSystemFoundation = Object.freeze({
    APP_VERSION,
    REGISTRY_VERSION,
    BROWSER_SCHEMA_VERSION,
    STATE_KEY,
    WORKSPACE_KEY,
    MANAGED_KEYS,
    migrate,
    boot,
    attachRegistry,
  });
})(window);
