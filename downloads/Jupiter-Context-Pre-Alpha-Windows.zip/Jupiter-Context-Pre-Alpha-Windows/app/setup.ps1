$ErrorActionPreference = "Stop"
$appRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$packageRoot = Split-Path -Parent $appRoot

Write-Host ""
Write-Host "FRANCIS OS v45 - WINDOWS SETUP" -ForegroundColor Cyan
Write-Host "Work agenda, personal media, focus tools, weather, news, and your private workspace." -ForegroundColor DarkGray
Write-Host "The dashboard works immediately; Google Calendar uses one private iCal address." -ForegroundColor Green
Write-Host ""

$nodeCommand = Get-Command node.exe -ErrorAction SilentlyContinue
if (-not $nodeCommand) {
  Write-Host "Node.js is not installed or Windows has not refreshed PATH yet." -ForegroundColor Yellow
  Write-Host "Install Node.js, restart Windows, and run INSTALL-FIRST.cmd again." -ForegroundColor Yellow
  Write-Host "Download: https://nodejs.org/" -ForegroundColor Cyan
  Read-Host "Press Enter to close"
  exit 1
}

$nodeVersionText = & $nodeCommand.Source --version
$nodeMajor = [int](($nodeVersionText -replace "^v", "").Split(".")[0])
if ($nodeMajor -lt 18) {
  Write-Host "Node.js 18 or newer is required. Detected: $nodeVersionText" -ForegroundColor Yellow
  Read-Host "Press Enter to close"
  exit 1
}

Write-Host "Node.js detected: $nodeVersionText" -ForegroundColor Green
$launcher = Join-Path $packageRoot "OPEN-DASHBOARD.cmd"

try {
  $listeners = Get-NetTCPConnection -LocalPort 4175 -State Listen -ErrorAction SilentlyContinue
  foreach ($listener in $listeners) {
    $owner = Get-Process -Id $listener.OwningProcess -ErrorAction SilentlyContinue
    if ($owner -and $owner.ProcessName -eq "node") {
      Stop-Process -Id $owner.Id -Force
      Write-Host "Closed the previous dashboard service so v45 can take over." -ForegroundColor Green
    }
  }
} catch {
  Write-Host "The previous dashboard service will be replaced after your next restart." -ForegroundColor DarkGray
}

try {
  Get-CimInstance Win32_Process -Filter "Name = 'powershell.exe'" -ErrorAction SilentlyContinue |
    Where-Object { $_.CommandLine -like "*folder-picker.ps1*" -or $_.CommandLine -like "*DASHBOARD_PICKER_DESCRIPTION*" } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
} catch {
  Write-Host "Any older hidden folder picker will close after your next restart." -ForegroundColor DarkGray
}

try {
  $taskArgument = '/c "' + $launcher + '"'
  $action = New-ScheduledTaskAction -Execute "cmd.exe" -Argument $taskArgument
  $trigger = New-ScheduledTaskTrigger -Daily -At "9:30AM"
  $settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries
  Register-ScheduledTask `
    -TaskName "Francis Daily Briefing" `
    -Action $action `
    -Trigger $trigger `
    -Settings $settings `
    -Description "Open Francis Dashboard with Work, Personal, and Focus scenes." `
    -Force | Out-Null
  Write-Host "Daily 9:30 AM task updated." -ForegroundColor Green

  $backgroundScript = Join-Path $appRoot "start.ps1"
  $backgroundArguments = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $backgroundScript + '" -NoBrowser'
  $backgroundAction = New-ScheduledTaskAction -Execute "powershell.exe" -Argument $backgroundArguments
  $backgroundTrigger = New-ScheduledTaskTrigger -AtLogOn
  Register-ScheduledTask `
    -TaskName "Francis Morning Dashboard Background" `
    -Action $backgroundAction `
    -Trigger $backgroundTrigger `
    -Settings $settings `
    -Description "Start Francis Dashboard quietly when Francis signs in." `
    -Force | Out-Null
  Write-Host "Background startup created for Chrome." -ForegroundColor Green
} catch {
  Write-Host "Windows did not allow the scheduled task to be created." -ForegroundColor Yellow
  Write-Host "The dashboard will still work from OPEN-DASHBOARD.cmd." -ForegroundColor Yellow
  Write-Host $_.Exception.Message -ForegroundColor DarkGray
}

Write-Host ""
Write-Host "Setup complete. Opening Francis OS v45..." -ForegroundColor Green
Start-Process -FilePath $launcher
Write-Host "You can close this setup window after the dashboard opens." -ForegroundColor Cyan
