param([switch]$NoBrowser)
$ErrorActionPreference = "Stop"
$appRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

function Test-MorningPort {
  try {
    $client = New-Object System.Net.Sockets.TcpClient
    $async = $client.BeginConnect("127.0.0.1", 4175, $null, $null)
    $connected = $async.AsyncWaitHandle.WaitOne(300)
    if ($connected) {
      $client.EndConnect($async)
      $client.Close()
      return $true
    }
    $client.Close()
    return $false
  } catch {
    return $false
  }
}

$nodeCommand = Get-Command node.exe -ErrorAction SilentlyContinue
if (-not $nodeCommand) {
  Write-Host "Node.js could not be found. Restart Windows and try again." -ForegroundColor Yellow
  Read-Host "Press Enter to close"
  exit 1
}

if (-not (Test-MorningPort)) {
  $serverPath = Join-Path $appRoot "server.cjs"
  $stdoutPath = Join-Path $appRoot "server-output.log"
  $stderrPath = Join-Path $appRoot "server-error.log"
  Remove-Item $stdoutPath, $stderrPath -ErrorAction SilentlyContinue

  Start-Process `
    -FilePath $nodeCommand.Source `
    -ArgumentList @('"' + $serverPath + '"') `
    -WorkingDirectory $appRoot `
    -WindowStyle Hidden `
    -RedirectStandardOutput $stdoutPath `
    -RedirectStandardError $stderrPath | Out-Null

  $ready = $false
  for ($attempt = 0; $attempt -lt 30; $attempt++) {
    Start-Sleep -Seconds 1
    if (Test-MorningPort) {
      $ready = $true
      break
    }
  }

  if (-not $ready) {
    Write-Host "The morning dashboard server could not start." -ForegroundColor Red
    if (Test-Path $stderrPath) {
      Write-Host ""
      Get-Content $stderrPath
    }
    if (Test-Path $stdoutPath) {
      Get-Content $stdoutPath
    }
    Read-Host "Press Enter to close"
    exit 1
  }
}

if (-not $NoBrowser) {
  Start-Process "http://localhost:4175/"
}
exit 0
