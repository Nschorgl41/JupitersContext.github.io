$ErrorActionPreference = "Stop"

try {
  $morning = Invoke-RestMethod -Uri "http://localhost:4175/api/morning" -TimeoutSec 30
} catch {
  Write-Host "The dashboard is not running." -ForegroundColor Yellow
  Write-Host "Open OPEN-DASHBOARD.cmd first, then try TERMINAL-VIEW.cmd again." -ForegroundColor Yellow
  Read-Host "Press Enter to close"
  exit 1
}

Clear-Host
Write-Host $morning.greeting -ForegroundColor Cyan
Write-Host $morning.dateLabel -ForegroundColor DarkGray
Write-Host ""
Write-Host "AUSTIN WEATHER" -ForegroundColor Yellow
Write-Host ("{0} F | {1}" -f $morning.weather.temperature, $morning.weather.condition) -ForegroundColor White
Write-Host ("High {0} F | Low {1} F | Rain {2}% | Wind {3} mph" -f $morning.weather.high, $morning.weather.low, $morning.weather.rainChance, $morning.weather.windSpeed) -ForegroundColor DarkGray
Write-Host ("AQI {0} ({1}) | Pollen {2}" -f $morning.conditions.aqi, $morning.conditions.aqiLabel, $morning.conditions.pollen) -ForegroundColor DarkGray

Write-Host ""
Write-Host "MORNING NEWS" -ForegroundColor Yellow
foreach ($item in $morning.news) {
  Write-Host ("[{0}] {1}" -f $item.category, $item.title) -ForegroundColor White
  Write-Host ("  {0} | {1}" -f $item.source, $item.url) -ForegroundColor DarkGray
}

Write-Host ""
Read-Host "Press Enter to close"
