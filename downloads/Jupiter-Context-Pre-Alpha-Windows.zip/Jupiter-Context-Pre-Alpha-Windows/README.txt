FRANCIS OS — WINDOWS EDITION v45
================================

APPLICATIONS AND DOCK
---------------------
v45 turns the Workspace Dock into a front-and-center application launcher. It
now sits in the dashboard flow directly beneath the ChatGPT command row instead
of floating over the bottom of the screen.

The Dock:

- Is centered and visible before the main Workspace panels.
- Never covers dashboard content.
- Allows icons and tooltips to rise above it without clipping.
- Retains independent pins for Work, Personal, and Focus.
- Uses registered launch behavior for every application.

PERSONAL DOCK
-------------
The recommended Personal Dock is intentionally simple:

- YouTube opens the YouTube home page in a new browser tab.
- Personal Files uses a clear folder icon and opens Family Photos in Windows
  File Explorer.
- Spotify opens the installed Windows application, with the web player as a
  fallback.
- Notebook opens directly inside Francis OS.

Interest Hub and Countdowns remain fully functional Personal applications, but
they no longer appear in the Dock or its pinning choices.

OTHER APPLICATION LAUNCHERS
---------------------------
- Google Calendar opens in a new browser tab.
- Work Files opens Personal Projects in Windows File Explorer.
- Focus Files opens the configured Francis OS storage root.
- Headlines, Quick Launch, Focus Timer, Objective, Settings, Integration
  Status, and other Francis-native applications open inside the dashboard.

SAFE V44 UPGRADE
----------------
Browser schema version 3 adds the ordered v44-to-v45 Dock migration:

- Interest Hub and Countdowns are removed only from Personal Dock pins.
- YouTube, Files, Spotify, and Notebook are guaranteed to remain available.
- Any other custom Personal pins keep their existing order.
- Workspace appearance, applications, layouts, topics, links, defaults,
  notifications, positions, objectives, and saved media remain unchanged.
- V42-to-V43 and V43-to-V44 migrations remain intact.
- Unsupported future schemas still stop safely without wiping data.

SYSTEM FOUNDATION
-----------------
- Application version 45
- Registry version 3
- Settings schema version 1
- Browser user-data schema version 3
- Every registered application exposes an internal launch definition, including
  launch mode, destination where applicable, and Dock eligibility.

PRESERVED EXPERIENCE
--------------------
All V42–V44 features remain available, including Workspaces, Calendar, weather,
headlines, Quick Launch, YouTube player, Spotify controls, Countdowns, Interest
Hub, Files/Vault, Notebook, Focus Timer, Objective, Integration Status,
Settings, Command Center, appearance, backup/restore, and protected connection
data.

INSTALL OR UPGRADE
------------------
1. Keep this entire folder together.
2. Double-click INSTALL-FIRST.cmd.
3. Approve the Windows prompt if one appears.
4. Setup replaces the older local service and opens Francis OS v45.

Node.js 18 or newer is required:
https://nodejs.org/

EVERYDAY USE
------------
- OPEN-DASHBOARD.cmd opens Francis OS.
- TERMINAL-VIEW.cmd opens the optional terminal summary.
- Local address: http://localhost:4175/
- System registry: http://localhost:4175/api/system/registry
- System health: http://localhost:4175/api/system/health

PRIVACY
-------
The server listens only on 127.0.0.1. Spotify tokens and the secret Google iCal
address remain in Windows local app-data and are excluded from backups and this
ZIP. Personal files remain under the configured Windows storage path.
