@echo off
title Francis Morning Dashboard Setup
powershell.exe -NoProfile -ExecutionPolicy Bypass -NoExit -File "%~dp0app\setup.ps1"
