@echo off
title Francis Morning Dashboard - Terminal
powershell.exe -NoProfile -ExecutionPolicy Bypass -NoExit -File "%~dp0app\terminal.ps1"
