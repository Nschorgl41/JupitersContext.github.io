@echo off
title Francis Morning Dashboard
powershell.exe -NoProfile -ExecutionPolicy Bypass -NoExit -File "%~dp0app\start.ps1"
